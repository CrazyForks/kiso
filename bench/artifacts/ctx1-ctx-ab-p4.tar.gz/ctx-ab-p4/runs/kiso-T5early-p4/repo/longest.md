# The three longest function bodies in src/

Length is `end - start` from `answers.json` (the span the `export function`
line opens and the column-0 `}` that closes it).

| # | length | file | function | lines |
|---|--------|------|----------|-------|
| 1 | 136 | cells/approval-panel.ts | `panelBlockLayout` | 619–755 |
| 2 | 93 | tui/lines.ts | `renderEvent` | 84–177 |
| 3 | 88 | cells/approval-panel.ts | `pickBlockRows` | 858–946 |

Next closest: `bannerLines` (cells/render.ts, 84), `askBlockRows`
(tui/ask-panel.ts, 71).
