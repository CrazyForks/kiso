/**
 * TUI v6 (ADR-0046) — THE one-compositor: every byte of the screen's
 * stdout comes from this file's doRender. `body.ts` + `dock.ts` are
 * RETIRED — this class implements BOTH façades (the `Body` mutations
 * the CLI's consumeRun calls, and the `Dock` chrome API), so the CLI
 * itself is untouched (zero diff outside the tui package + tests).
 *
 * The model:
 *  - cells (the CLI's mutation surface) → components → lines;
 *  - `lines[] + commitIndex` (the scrollback fork — the departure from
 *    the reference implementation's model): a line COMMITS (leaves the
 *    live region) via the real-LF
 *    scroll at the last row (`\x1b[1B\n` — CUP-free) when its cell is
 *    DONE and the region needs the room. Within a geometry, committed
 *    bytes are never re-emitted — the native scrollback gets them. The
 *    one exception is a SETTLED RESIZE (ADR-0046 Amendment 1, R14):
 *    `2J H 3J`, then the whole session reprinted from the model, so the
 *    terminal holds exactly one rendering; the shell history the
 *    terminal held before kiso started is the declared cost;
 *  - the live region (content + chrome + menu) is hard-capped: the
 *    content at H−4 (V6-3 — the four-row chrome); overflow FORCE-
 *    commits the oldest live cell that has a committed form — never a
 *    tool call still running (DC-53); a running card's window shrinks
 *    to the room instead (DC-43);
 *  - two crash invariants: ① every emitted line's visible width ≤ W
 *    (components fold; a violation THROWS with diagnostics — the
 *    no-silent-truncate ruling); ② every steady-
 *    frame CUP lands in the CONTENT area (rows ≤ H−4−menu — the
 *    committed band, the stale/gap ELs, and the LIVE lines at their
 *    model rows; fix C's sanctioned reinterpretation, ADR-0046) — the
 *    CHROME rows (H−3..H) are RELATIVE-only (vertical A/B, horizontal
 *    G/D); CUP over the whole screen exists only in the full-redraw
 *    path (the first frame, the resize repaint);
 *  - the cursor DERIVES from the frame: the focus component embeds the
 *    APC marker in its rendered line; the compositor locates, strips,
 *    and relatively positions from the frame — no side-channel cursor
 *    bookkeeping that could desync from the picture;
 *  - zero timers: the spinner animation is a dirty flag through the
 *    scheduler — a one-shot setTimeout re-armed only while a running
 *    tool exists (the #14/#15 zero-output contract is structural).
 *
 * Layout at H rows (V6-3 — the design §03 chrome; W6 — the box):
 * content rows 1..H−4, box top H−3, editor (the slot) H−2, box
 * bottom H−1, status H.
 * Pipes / NO_COLOR: the passthrough branches below keep the v2a/v2b
 * line-mode bytes byte-for-byte (the e2e guards them).
 */

import { truncateDiff } from "./diff.js";
import { MENU_ITEMS, displayWidth, type MenuItem } from "./editor.js";
import { leadWidth } from "./width.js"; // W23: the ONE width authority (the editor, #inputRow, and editCol share it)
// KC3.5: the panel-slot reads come from the DISPATCHERS — one source
// for four reads, so an ask can never render half as an approval.
import { panelFrameOf, panelLeadOf, panelStatusOf } from "./ask-panel.js";
import { MOUSE_OFF } from "./editor.js";
import type { PanelState } from "./approval-panel.js";
import { atPanelRows, bandHeader, type AtMatch } from "./at-picker.js";
// TUI2-R2 ②: the session picker's rows — the band's third occupant.
import { sessionPickerRows, type SessionPickState } from "./session-picker.js";

/** KC3 §4 — the @ picker's bound state (the editor's atState()). */
export interface AtPanelState {
	readonly matches: readonly AtMatch[];
	readonly selected: number;
	readonly capped: boolean;
}
import {
	CAP_PREVIEW,
	thinkingRow,
	Container,
	MOTION_FRAMES,
	MdStream,
	bodySpacing,
	boxBottom,
	boxTop,
	cellComponent,
	gutterCut,
	cutLine,
	pendingQueueRows,
	statusLine,
	visibleWidth,
	type BodyCell,
	type FrameCtx,
	breathFrame,
} from "./components.js";
import { bannerLines, escapeTerminal, foldResult, foldThinking, palette, renderTerminalGap, renderToolSummary, type BannerMeta, type ResumeMeta } from "./lines.js";
import { oneRow } from "@vincemakes/kiso-tui-cells/render";
import { displayVerb, keysSheetRows } from "./strings.js";
/** DC-56: does a rendered row carry any visible text once its SGR is
 *  stripped? A washed pad row is spaces under a background colour — width
 *  without words. */
const saysSomething = (row: string): boolean => row.replace(/\x1b\[[0-9;?]*[A-Za-z]/g, "").trim() !== "";

// R5 — the transcript viewer's PURE projection. The compositor supplies
// the entries (it holds the cells); the arrangement lives there.
import {
	VIEWER_GUTTER,
	viewerFlat,
	viewerHint,
	viewerInit,
	viewerMove,
	viewerRows,
	viewerScroll,
	viewerTitle,
	viewerToggle,
	viewerToggleAll,
	type ViewerEntry,
	type ViewerState,
} from "./transcript.js";

/** The cursor marker — an APC private sequence the focus component
 *  embeds at the edit position; the compositor strips it and moves
 *  relatively (it never reaches the terminal). */
export const CURSOR_MARKER = "\x1b_[kiso-cur]\x1b\\";

const FRAME_MS = 16; // state changes coalesce to ≥16ms frames
const SPINNER_MS = 200; // the spinner cadence — a ONE-SHOT re-armed on demand
/** REL-0152-R1: a held row that has never been painted, so the first
 *  frame writes every row rather than trusting an empty string. */
const NOT_PAINTED = "\u0000never";

/** REL-0152-D18 — how long a drag has to be quiet before it is over.
 *  Long enough that a continuous drag never crosses it, short enough
 *  that a single resize still feels immediate. */
const RESIZE_SETTLE_MS = 80;

const CHROME_ROWS = 4; // box top + input + box bottom + status — the design §03 chrome (V6-3; the box is W6)

/** R3i — how many calls in flight the act window shows at once. Beyond
 *  it the block would grow with the model's parallelism, which is the
 *  same unbounded height the projection exists to remove; the rest are
 *  COUNTED, never dropped silently. */
const LIVE_ACT_HEADS = 3;
/** R8 — the command band's window: five rows plus a counter, the same
 *  budget the composer's own ceiling can afford above it. */
const MENU_WINDOW = 5;

/** KC1 §5 — the input row's bound state. The legacy pair stays
 *  REQUIRED and keeps its exact meaning (the cursor line's visible
 *  slice and its display column), so a one-row provider — the old
 *  `{line, cursor}` shape — keeps working unchanged; the composer's
 *  rows ride as OPTIONAL fields, which is what makes the CLI's binding
 *  signature-neutral (zero cli source growth). */
export interface InputState {
	readonly line: string;
	readonly cursor: number;
	/** the visible rows (≤ N_visible), dim "…" markers included */
	readonly lines?: readonly string[];
	/** the cursor's row within `lines` */
	readonly cursorRow?: number;
	/** the cursor's display column within that row */
	readonly cursorCol?: number;
}

export interface BodyOptions {
	/** REL-0150-D1 test seam: overrides the TERM_PROGRAM detection for
	 *  the conservative frame mode — process.env is SHARED across
	 *  concurrently-running test files in one worker, so a test that
	 *  mutated the env would bleed 40ms frames into its neighbors. */
	readonly termProgram?: string;
	/** Is the cell renderer live? A color TTY with a real size — checked
	 *  per mutation (the TIOCSWINSZ can land after main constructs us). */
	active: () => boolean;
	/** The terminal height (rows) — live, for the region geometry. */
	height: () => number;
	/** The terminal width (cols) — live, for wrap estimates. */
	width: () => number;
	/** v6: RETIRED — the cursor derives from the frame's marker. Kept in
	 *  the interface so the CLI's construction is untouched. */
	editCol: () => number;
	/** v6: RETIRED — the compositor draws the chrome itself. Same. */
	onDock?: () => void;
	/** The stdout writer — injectable for unit tests (default: stdout). */
	write?: (s: string) => void;
}

/** One turn's record, pushed at userLine. `ended` is what the live
 *  projection reads (the `thinking…` placeholder stands only while a
 *  turn is in flight); `begun` and `hasText` are the turn's two
 *  boundaries as the compositor sees them.
 *
 *  DECLARED REVERSAL (R13, owner-ruled 2026-09-03): the record used to
 *  carry the folded-turn line's terms (reads / edits / others / seen /
 *  words / folded) and a list of SEGMENTS (R3b–R3i), each with its own
 *  counters, thinking clock and fold anchor. Every one of those existed
 *  to decide the fold; with nothing folding, nothing read them, and
 *  they went with the mechanism. */
interface TurnRecord {
	ended: boolean;
	hasText: boolean;
	begun: boolean;
	thoughtSeconds: number;
}

/** W20 — the whole-table-replace comparison: the live task block only
 *  redraws when the items actually changed (the task extension's
 *  idempotent shape — an unchanged replace is a no-op, no frame). */
function sameTask(a: { text: string; status: "pending" | "active" | "done" }[], b: { text: string; status: "pending" | "active" | "done" }[]): boolean {
	return a.length === b.length && a.every((x, i) => x.text === b[i]!.text && x.status === b[i]!.status);
}

/** The one compositor — implements the Body façade AND the Dock chrome
 *  API (see the class comments on each method group). */
/** The chrome a frame wears and the room it leaves the live region —
 *  one derivation for the frame (`render`) and for the scalar
 *  (`liveCount`): `rows` is what the chrome costs, `cap` the content
 *  cap V6-3 leaves (H−4, less the composer's extra rows and the queue
 *  band; KC1 §6, W22). */
interface Chrome {
	readonly menuRows: string[];
	readonly queueRows: string[];
	readonly editor: { rows: string[]; markerRow: number; markerCol: number };
	readonly inputExtra: number;
	readonly rows: number;
	readonly cap: number;
}

export class Body {
	#opts: BodyOptions;
	#cells: BodyCell[] = [];
	#lineCache: (string[] | null)[] = []; // the committed cells' rendered lines (immutable)
	#committed = 0; // the count of leading cells fully committed
	#committedLines = 0; // their total line count (incremental — O(1) per frame)
	#active = false;
	#docked = false;
	#dirty = false;
	#fullRedraw = false; // the first frame / resize — the CUP path
	#lastLiveTop = 0; // the recorded live region top — the resize clear starts here
	#lastLiveRows = 0; // the recorded live row count (incl. the chrome)
	#lastSkip = 0; // the last frame's window top in model rows — the A8b scroll's leaving-count base
	/**
	 * REL-0152-R1 — the SCREEN, held.
	 *
	 * H strings: what the terminal is showing right now, as this
	 * compositor believes it. Every frame computes the screen it WANTS
	 * and writes only the rows where the two differ.
	 *
	 * This is the whole round. The old renderer's correctness came from
	 * remembering what it had written — which rows it had painted, which
	 * it had scrolled, what the window's top had been last time — and
	 * every defect in the D series that survived a patch came from that
	 * memory disagreeing with the terminal. A renderer that HOLDS the
	 * screen cannot disagree with itself: it computes a difference and
	 * emits it, and a row that is wrong for any reason is repaired on the
	 * next frame because the difference includes it.
	 *
	 * Six fixes were built and reverted before this — one for the tear,
	 * five for the chip loss — and each traded a loss for a duplicate
	 * somewhere else. They were all attempts to make the memory agree.
	 *
	 * The one thing a diff cannot repair is the SCROLLBACK, which is
	 * irreversible: see #scrolledOff.
	 */
	#screen: string[] = [];
	/**
	 * REL-0152-R1 — the row the cursor is on, as far as this compositor
	 * knows.
	 *
	 * The park at the end of a frame is a RELATIVE move, and the old
	 * renderer could hard-code its base: the bottom-up march always ended
	 * on the status row at H, so `from` was H by construction. A diff
	 * ends wherever the last CHANGED row happens to be — which on a
	 * streaming frame is the live band, not the bottom of the screen — so
	 * the base has to be tracked rather than assumed.
	 *
	 * Getting this wrong does not damage the frame; it parks the cursor
	 * in the wrong place, which is what the PTY gates that assert "every
	 * frame ends with the cursor on an input row" are for. They caught it.
	 */
	#cursorRow = 0;
	/**
	 * REL-0152-R1 — how many model rows have gone into the terminal's
	 * scrollback. Monotonic, because scrolling is.
	 *
	 * A row may only be scrolled off when it can never be shown again.
	 * The window is bottom-anchored, so its top moves BOTH ways as the
	 * live band grows and shrinks; scrolling on that movement pushed rows
	 * away that the next shrink brought back, which is the A7 replay's
	 * frame-106 duplicate. The floor below is where the window's top
	 * would sit with the live band empty and the chrome at its minimum —
	 * the only part of the movement that is one-way.
	 */
	#scrolledOff = 0;
	/** REL-0152-R1: this frame is the repaint after a SIGWINCH. */
	#resizeFrame = false;
	/** REL-0152-D18: a drag's signals are still arriving. */
	#resizePending = false;
	/** REL-0152-D19: the inherited terminal has not been released yet. */
	#needsReset = false;
	#resizeTimer: ReturnType<typeof setTimeout> | null = null;
	#lastH = 0;
	/** R14 — the geometry the last frame PAINTED, and the snapshot of it
	 *  taken when a winch opens a settle window.
	 *
	 *  Three versions of this question were wrong before this one.
	 *  Seeding in `enter()` never ran under the unit pool (it bails on a
	 *  non-TTY), so a same-size winch erased the scrollback. Comparing
	 *  against the CURRENT frame's geometry let an ordinary frame render
	 *  at the new size between the winch and the settle and eat the
	 *  change, so a real resize silently stopped reprinting. Seeding once
	 *  on the first frame had the same hole whenever the first frame had
	 *  not run yet.
	 *
	 *  The question the settle actually asks is "is the terminal holding
	 *  a rendering made at a DIFFERENT geometry than the one we have
	 *  now" — so the comparison is against what was on screen when the
	 *  winch arrived, snapshotted then, once per storm. */
	#paintedW = 0;
	#paintedH = 0;
	#winchFromW = 0;
	#winchFromH = 0;
	/** DC-50 — the ONE expansion switch ctrl+o flips. */
	#expandedAll = false;
	// KC1 §6: the composer's recorded extent — the row count the last
	// frame drew (exit's clear walks it) and the row its CHA parked the
	// cursor on (the steady frame's relative anchor). N = 1 reproduces
	// the retired constants exactly (one input row, the anchor at H−2).
	#lastInputRows = 1;
	#lastAnchorRow = 0;
	#frameTimer: NodeJS.Timeout | null = null;
	#spinnerTimer: NodeJS.Timeout | null = null;
	#spinnerI = 0;
	#lastThinking: string | null = null;
	#lastTool: { name: string; input: Record<string, unknown>; result: { content: string; isError: boolean } } | null = null;
	#pendingCalls = new Map<string, { name: string; input: Record<string, unknown>; result: { content: string; isError: boolean } }>();
	#pipeBuf = ""; // the passthrough's thinking buffer
	// §2.3 — the ctrl+t switch. A block that completes AFTER the press
	// inherits it, so the session stays one way up rather than mixing.
	#thinkingFolded = false;
	/** TUI2-MD ⑤ — the markdown scanner of the message currently
	 *  streaming, and the cell index its first block landed at. Null
	 *  between messages: the scanner's life is one assistant message. */
	#md: MdStream | null = null;
	#mdBase = 0;
	#toolCells = new Map<string, number>(); // callId → cell index (parallel tools)
	// W15: the collapsed (cut) tool cells — committed cells whose last
	// rendered row carried the "ctrl+o" affordance.
	//
	// DC-50 / R14: the expand key no longer WALKS this. It is the
	// VIEWER's index now (ctrl+r, `#viewerEntries`) — the two surfaces
	// coexist and §9 says so. It is kept, not retired, for that reader.
	#collapsed: number[] = [];
	// the turn records — one per userLine; the cells carry the record's
	// index as their turn boundary.
	#turns: TurnRecord[] = [];
	#write: (s: string) => void;
	#resizeHandler: (() => void) | null = null;
	/** TUI2-R3v2 ②: the panel option rows' absolute screen span, as of the
	 *  last frame. Null whenever no clickable list is on screen. */
	#panelRowSpan: { top: number; count: number; first: number } | null = null;
	// the chrome state (the Dock façade)
	#status = "";
	#statusHint: string | null = null;
	#tail = "";
	// W21: the panel's bound state — the PanelSelect slot occupant (the
	// old ApprovalPrompt's question slot retires with it): while a
	// panel is up it replaces the live region, owns the input lead, and
	// derives the status row (the CLI's painting status yields).
	#panelState: (() => PanelState | null) | null = null;
	/** TUI2-R1 (D): the keys sheet's slot read — the editor's boolean.
	 *  Unbound, the sheet cannot render and every frame is byte-identical
	 *  to before the round. */
	#sheetState: (() => boolean) | null = null;
	/** R5 — the transcript viewer's state, or null when it is closed. It
	 *  lives HERE rather than in the editor because its entries are the
	 *  compositor's cells; the editor only sends it commands. */
	#viewer: ViewerState | null = null;
	#viewerWasUp = false;
	/** TUI2-R1.5 7(a): the sheet's previous up/down state — a transition
	 *  in either direction takes the full-redraw path. */
	#sheetWasUp = false;
	/** This frame is an overlay open or close — it must not scroll. */
	#overlayFrame = false;
	#inputState: () => InputState = () => ({ line: "", cursor: 0 });
	#inputPrompt = "";
	#menuState: (() => { items: readonly MenuItem[]; selected: number } | null) | null = null;
	// KC3 §4: the @ picker's bound state — the SAME band as the menu
	// (see #menuRows: the two are mutually exclusive by construction).
	#atState: (() => AtPanelState | null) | null = null;
	// TUI2-R2 ②: the session picker's bound state — the same band again
	// (see #menuRows), and modal, so it takes the band first.
	#pickState: (() => SessionPickState | null) | null = null;
	// W22: the pending-turn queue's bound state — the CLI's live slots
	// (chat.ts); the chips render in the menu-rows family (above the
	// box top), the live caps shrink by their rows, and the status
	// row's right hint shows the count while any turn waits.
	#queueState: () => readonly string[] = () => [];

	/** REL-0150-D1 — the conservative frame mode. Terminal.app does not
	 *  support DEC 2026 synchronized output (half-frames paint on its own
	 *  schedule — the reviewer dogfood watched the tearing live) and its
	 *  renderer is throughput-weak (typed input lagged seconds behind the
	 *  stream). Where TERM_PROGRAM says Apple_Terminal: the frame wraps
	 *  in ?25l/?25h (cursor hidden during the repaint — the classic
	 *  anti-tearing degrade; every frame re-shows it) instead of the dead
	 *  2026 bytes, and the coalesce window widens 16→40ms (fewer, bigger
	 *  frames: fewer tear opportunities, less renderer pressure). Every
	 *  other terminal keeps today's bytes exactly. Heuristic on purpose —
	 *  a DECRQM round-trip would race the editor for stdin at boot. */
	readonly #conservative: boolean;
	readonly #frameMs: number;
	/** REL-0152-R1: the frame's own writer — the ONE path that does not
	 *  invalidate the held screen, because it is what produced it. */
	readonly #writeFrame: (s: string) => void;
	/** REL-0152-R1: true only while the frame's own bytes are going out. */
	#inFrame = false;
	#unguard: (() => void) | null = null;

	constructor(opts: BodyOptions) {
		this.#opts = opts;
		// REL-0152-R1: every write that is NOT this frame's own goes
		// through here and INVALIDATES the held screen.
		//
		// A banner, a bodyLog line, the terminal gap, the pipe path's
		// prose — all of them paint the terminal directly, and the old
		// renderer survived that because every frame repainted every row.
		// A diff does not: after such a write the held screen describes a
		// terminal that no longer exists, and the next frame skips exactly
		// the rows it should have repaired. That is a stale composer row
		// left standing while the real one moves — which is what the PTY
		// cursor gates saw.
		//
		// Forgetting is cheap and cannot be forgotten to do: one frame
		// repaints, and correctness stops depending on a list of writers
		// staying complete as the file grows.
		const raw = opts.write ?? ((str: string) => process.stdout.write(str));
		this.#writeFrame = raw;
		this.#write = (str: string): void => {
			this.#screen = [];
			raw(str);
		};
		this.#conservative = (opts.termProgram ?? process.env.TERM_PROGRAM) === "Apple_Terminal";
		this.#frameMs = this.#conservative ? 40 : FRAME_MS;
		this.#active = opts.active();
		// v6: the single writer — the compositor IS the dock; the CLI's
		// onDock callback (which used to re-pin the dock after a scroll)
		// is retired with the split.
		// TUI2-R2pre ③: taking the ref SUPERSEDES whatever held it, so the
		// outgoing compositor's resize listener comes off here. It is not
		// only listener hygiene: every Dock call now reaches THIS instance,
		// so a resize heard by the old one would have a compositor that owns
		// no part of the screen paint a full redraw over it.
		// (an explicit null check, not `?.#` — TS18030: an optional chain
		// cannot contain a private identifier, and vitest transpiles without
		// type-checking, so only `npm run typecheck` sees the difference)
		if (compositorRef !== null) compositorRef.#detachResize();
		compositorRef = this;
		// the Dock façade's bindings may arrive BEFORE this construction
		// (the CLI binds the editor state in makeLineInput, then constructs
		// the Body) — the LIVE binding buffer applies here, or the input
		// row would never render the typed line. W21: the buffer is a
		// mutable object the bind methods update in place — order-agnostic
		// (the old snapshot froze `menu` at bindInput time and the menu
		// silently never bound in the real CLI; the e2e gates bind the
		// Body directly and could not see it).
		if (dockBindings.state !== null) this.#inputState = dockBindings.state;
		this.#inputPrompt = dockBindings.prompt;
		if (dockBindings.menu !== null) this.#menuState = dockBindings.menu;
		if (dockBindings.at !== null) this.#atState = dockBindings.at;
		if (dockBindings.pick !== null) this.#pickState = dockBindings.pick;
		this.#panelState = dockBindings.panel;
		this.#sheetState = dockBindings.sheet;
		if (dockBindings.queue !== null) this.#queueState = dockBindings.queue;
	}

	/** Live re-check — a TTY whose size lands after construction flips in. */
	#isActive(): boolean {
		this.#active = this.#opts.active();
		return this.#active;
	}

	// ---- the Body façade: mutations (the ONLY way the CLI touches state) ----

	userLine(text: string): void {
		if (!this.#isActive()) {
			this.#closeOpenThinking();
			this.#closeOpenText();
			const p = palette();
			this.#write(`${p.bold}you> ${escapeTerminal(text)}${p.reset}\n`);
			return;
		}
		this.#closeOpenThinking();
		this.#closeOpenText();
		// the turn boundary; the cell carries the record's index.
		this.#turns.push({ ended: false, hasText: false, begun: false, thoughtSeconds: 0 });
		this.#cells.push({ kind: "user", text, done: true, turn: this.#turns.length - 1 });
		this.#mark();
	}

	thinkingAppend(text: string): void {
		if (!this.#isActive()) {
			this.#pipeBuf += text; // buffered; the fold prints at the block's end
			return;
		}
		const last = this.#cells[this.#cells.length - 1];
		if (last !== undefined && last.kind === "thinking" && !last.done) {
			last.text += text;
		} else {
			this.#cells.push({ kind: "thinking", text, done: false, turn: this.#turns.length - 1 });
			// R7 (owner-ruled 2026-08-31): thinking is WORDS, not work — a
			// cell like prose.
			const t0 = this.#turns[this.#turns.length - 1];
			if (t0 !== undefined) t0.begun = true;
			// R3i: the beat starts HERE. Law 1.4 says "a running thought
			// twinkles", and `#armSpinner`'s predicate includes an open
			// thinking cell — but its only caller used to be `toolRunning`,
			// so a turn that thought and did nothing else never moved.
			this.#armSpinner();
		}
		this.#mark();
	}

	thinkingEnd(): void {
		const last = this.#cells[this.#cells.length - 1];
		if (last !== undefined && last.kind === "thinking" && !last.done) {
			last.done = true;
			// §2.3: a block that SETTLES after the switch was thrown is
			// folded like the rest — the session stays one way up.
			last.folded = this.#thinkingFolded;
			this.#lastThinking = last.text;
			if (!this.#isActive()) this.#write(foldThinking(last.text));
			this.#mark();
		}
	}

	toolStart(name: string, callId: string, input: Record<string, unknown>): void {
		const summary = JSON.stringify(input).slice(0, 60);
		this.#pendingCalls.set(callId, { name, input, result: { content: "", isError: false } });
		if (!this.#isActive()) {
			this.#closeOpenThinking();
			this.#closeOpenText();
			this.#write(`→ ${escapeTerminal(name)}(${escapeTerminal(JSON.stringify(input).slice(0, 200))})\n`);
			return;
		}
		// TUI2-R1.5 ① (VD-1): the tool's start CLOSES an open text block —
		// the inactive path above has always done this; the active path
		// forgot, and the consequence was structural. textAppend only ever
		// grows the LAST cell, so a text block with a tool cell after it can
		// never receive another byte: it is finished in fact while its
		// `done` flag says otherwise. The commit loop takes leading DONE
		// cells, so that one stale flag parked the whole rest of the turn
		// behind it — every tool cell then reached the screen through the
		// FORCE-commit path.
		this.#closeOpenThinking();
		this.#closeOpenText();
		// W12: the cell carries the delegate's child roles from the FULL
		// input — the display summary is sliced at 60 chars (unparseable);
		// the roles are the only running-state data the parent holds (there
		// is no live channel to a running child session).
		const childRoles: string[] = [];
		for (const t of Array.isArray(input.tasks) ? (input.tasks as unknown[]) : []) {
			if (typeof t === "object" && t !== null && typeof (t as { role?: unknown }).role === "string") {
				childRoles.push((t as { role: string }).role);
			}
		}
		this.#toolCells.set(callId, this.#cells.length);
		this.#cells.push({ kind: "tool", name, input: summary, inputFull: JSON.stringify(input, null, 2), childRoles, state: "pending", isError: false, resultText: "", diff: null, added: 0, removed: 0, startedAt: null, doneAt: null, done: false, expanded: false, turn: this.#turns.length - 1, reason: null, verdict: null });
		// R3i phase 5 — an ANSWER is words (law 1.7): `ask_user` never
		// counted as the turn's work, so it does not mark the turn begun.
		const turn = this.#turns[this.#turns.length - 1];
		if (turn !== undefined && name !== "ask_user") turn.begun = true;
		this.#mark();
	}

	toolApproval(callId: string, diff: import("./diff.js").DiffResult | null): void {
		if (!this.#isActive()) return;
		const cell = this.#toolCell(callId);
		if (cell !== null && cell.kind === "tool" && !cell.done) {
			cell.state = "approval";
			cell.diff = diff === null ? null : truncateDiff(diff.lines);
			cell.added = diff?.added ?? 0;
			cell.removed = diff?.removed ?? 0;
		}
		this.#mark();
	}

	/** A5: the approval verdict — the permission_decided event binds into
	 *  the cell (the aggregated head row: name + status + decidedBy in
	 *  ONE row; no free-standing `  approved` orphan). The decision lands
	 *  after the panel closes (the streamed event) — the cell is usually
	 *  running by then; the record rides the settled row (`· approved by
	 *  X` on an extension's auto-approval, `· by X` on its denial). A
	 *  verdict with no live cell is dropped — the registry holds only
	 *  in-flight calls, and the committed cells already told their
	 *  outcome. */
	toolVerdict(callId: string, decision: "approved" | "denied", decidedBy?: string, reason?: string): void {
		if (!this.#isActive()) return;
		const cell = this.#toolCell(callId);
		if (cell !== null && cell.kind === "tool") {
			cell.verdict = { decision, ...(decidedBy !== undefined ? { decidedBy } : {}), ...(reason !== undefined ? { reason } : {}) };
			this.#mark();
		}
	}

	toolRunning(callId: string): void {
		if (!this.#isActive()) {
			const p = palette();
			this.#write(`${p.dim}  running…${p.reset}\n`);
			return;
		}
		const cell = this.#toolCell(callId);
		if (cell !== null && cell.kind === "tool" && !cell.done) {
			cell.state = "running";
			cell.startedAt = Date.now();
			this.#armSpinner();
		}
		this.#mark();
	}

	/**
	 * TUI2-R1 (C) — the RUNNING call's observed output.
	 *
	 * The CLI tails the shell tool's progress sidecar and hands what it
	 * read to the cell. Deliberately narrow: only a cell that is still
	 * RUNNING accepts it, so an observation can never overwrite a real
	 * result, and an unchanged read costs no frame at all (a poller
	 * fires far more often than the output changes).
	 *
	 * This adds no event and no durable state. The text lands in the
	 * cell's live rendering and is replaced wholesale by the tool's own
	 * result at settle — which is the only text anything else ever reads.
	 */
	toolProgress(callId: string, text: string): void {
		if (!this.#isActive()) return; // the pipe path has no live region
		const cell = this.#toolCell(callId);
		if (cell === null || cell.kind !== "tool" || cell.state !== "running" || cell.done) return;
		if (cell.resultText === text) return;
		cell.resultText = text;
		this.#mark();
	}

	toolSucceeded(callId: string): void {
		if (!this.#isActive()) this.#write("  ok\n");
	}

	toolFailed(callId: string, error: string): void {
		if (!this.#isActive()) {
			const p = palette();
			this.#write(`${p.red}  failed: ${escapeTerminal(error.slice(0, 160))}${p.reset}\n`);
		}
	}

	toolResult(callId: string, result: { content: string; isError: boolean; reason?: string | null }): void {
		const call = this.#pendingCalls.get(callId);
		if (call !== undefined) {
			call.result = result;
			this.#lastTool = { name: call.name, input: call.input, result };
			this.#pendingCalls.delete(callId);
		}
		if (!this.#isActive()) {
			// W19: the pipe path renders the SAME pinned deny row (the
			// reason in the W4 parentheses idiom), byte-clean — plus the
			// folded [result ✗] body below (never hide information).
			const p = palette();
			this.#write(
				`${renderToolSummary(call?.name ?? "?", call?.input ?? {}, result, result.reason ?? null)}\n` +
					`${p.dim}${result.isError ? p.red : p.dim}  [result${result.isError ? " ✗" : ""}] ${foldResult(result.content)}${p.reset}\n`,
			);
			return;
		}
		const cell = this.#toolCell(callId);
		this.#toolCells.delete(callId);
		if (cell !== null && cell.kind === "tool" && !cell.done) {
			cell.state = "done";
			cell.isError = result.isError;
			cell.resultText = result.content;
			cell.reason = result.reason ?? null;
			cell.doneAt = Date.now();
			cell.done = true;
		}
		this.#mark();
	}

	textAppend(text: string): void {
		if (!this.#isActive()) {
			this.#closeOpenThinking();
			this.#closeOpenText();
			this.#write(escapeTerminal(text));
			return;
		}
		const turn = this.#turns[this.#turns.length - 1];
		if (turn !== undefined) turn.hasText = true;
		// TUI2-MD ⑤: assistant body text is MARKDOWN, scanned as it
		// streams. The scanner yields CLOSED blocks (final source, final
		// render) and one OPEN tail block; each becomes a cell, and the
		// cell is the commit unit the compositor already had — so
		// block-freeze needs no new commit machinery at all. A closed
		// block is a DONE cell the natural loop freezes; the tail is the
		// one cell left live, repainting in place.
		if (this.#md === null) {
			this.#closeOpenThinking();
			this.#closeOpenText();
			this.#md = new MdStream();
			this.#mdBase = this.#cells.length;
		}
		this.#md.push(text);
		this.#syncMd();
		this.#mark();
	}

	/** TUI2-MD ⑤ — mirror the scanner's blocks onto cells. Append-only by
	 *  construction: a block that has closed never changes, so a cell that
	 *  is done is never touched again (and a committed one could not be).
	 *  Only the trailing tail cell is rewritten per delta. */
	#syncMd(): void {
		if (this.#md === null) return;
		const blocks = this.#md.blocks();
		const closed = this.#md.closed();
		for (let i = 0; i < blocks.length; i += 1) {
			const at = this.#mdBase + i;
			const cell = this.#cells[at];
			if (cell === undefined) {
				this.#cells.push({ kind: "md", block: blocks[i]!, done: i < closed });
				continue;
			}
			if (cell.kind !== "md" || cell.done) continue;
			cell.block = blocks[i]!;
			cell.done = i < closed;
		}
		// the tail can vanish (a lone whitespace delta that turns out to be
		// a blank line). Drop it only where dropping is safe: never below
		// the commit frontier, where the bytes are already the terminal's.
		const want = this.#mdBase + blocks.length;
		while (this.#cells.length > Math.max(want, this.#committed) && this.#cells[this.#cells.length - 1]!.kind === "md") this.#cells.pop();
	}

	/** TUI2-MD ⑤ — the message ends: the tail block closes and every md
	 *  cell of this message is final. */
	#endMd(): void {
		if (this.#md === null) return;
		this.#md.end();
		this.#syncMd();
		for (let i = this.#mdBase; i < this.#cells.length; i += 1) {
			const cell = this.#cells[i]!;
			if (cell.kind === "md") cell.done = true;
		}
		this.#md = null;
	}

	textEnd(): void {
		if (!this.#isActive()) {
			this.#write("\n");
			return;
		}
		this.#endMd();
		this.#mark();
	}

	/** The turn boundary's END: the CLI calls this at the run's terminal
	 *  event, once per run, BEFORE the recap. `thoughtSeconds` is the
	 *  CLI's wall-clocked thinking window. */
	endTurn(thoughtSeconds: number): void {
		if (!this.#isActive()) return;
		const turn = this.#turns[this.#turns.length - 1];
		if (turn === undefined || turn.ended) return;
		turn.ended = true;
		turn.thoughtSeconds = thoughtSeconds;
		// W20: the turn's live task block settles HERE — the ONE recap
		// block for the turn ("`task done · N items · <duration>", the
		// duration clocked compositor-side from the block's first call —
		// the CLI stays unchanged). A turn that never touched the list has
		// no live block — nothing settles. Newest-first: the live block is
		// the newest cell of its turn.
		for (let i = this.#cells.length - 1; i >= 0; i -= 1) {
			const c = this.#cells[i]!;
			if (c.kind === "checklist" && !c.done) {
				c.done = true;
				c.durationSeconds = Math.max(0, Math.round((Date.now() - c.startedAt) / 1000));
				break;
			}
		}
		// R3g (fable D3, 2026-08-28): an INTERRUPTED tool never receives a
		// result, so its cell stays `done: false` — and the commit loop
		// stops at the first cell that is not done. One esc mid-tool
		// therefore parked the commit pointer for the REST of the
		// session: every later turn's rows piled up in the live region
		// and only ever left it through the force-commit cap. The turn's
		// end is the boundary that closes them, exactly as it closes an
		// open thinking cell. `reason` is set so the row keeps its words
		// (law 1.3: trouble is never summarised away).
		for (const c of this.#cells) {
			if (c.kind === "tool" && !c.done) {
				c.state = "done";
				c.reason = "interrupted";
				c.doneAt = Date.now();
				c.done = true;
			}
		}
		// the QUIET turn: an open thinking cell closes at the boundary —
		// its natural closer is the text's arrival, which a text-less turn
		// never has, and the commit loop only takes done cells.
		for (let i = this.#cells.length - 1; i >= 0; i -= 1) {
			const c = this.#cells[i]!;
			if (c.kind === "thinking" && !c.done) {
				c.done = true;
				this.#lastThinking = c.text;
				break;
			}
		}
		this.#mark();
	}

	terminal(label: string, statusLineText: string): void {
		if (!this.#isActive()) {
			this.#closeOpenThinking();
			this.#closeOpenText();
			this.#write(label + renderTerminalGap(statusLineText));
			return;
		}
		this.#closeOpenThinking();
		this.#closeOpenText();
		this.#cells.push({ kind: "terminal", label: label.trim(), line: statusLineText, done: true });
		this.#mark();
	}

	notice(text: string): void {
		if (!this.#isActive()) {
			this.#closeOpenThinking();
			this.#closeOpenText();
			this.#write(`${text}\n`);
			return;
		}
		this.#closeOpenThinking();
		this.#closeOpenText();
		this.#cells.push({ kind: "notice", text, done: true });
		this.#mark();
	}

	/** W20 — the task checklist as STATE, not events: the FIRST call of a
	 *  turn creates the ONE live block (done:false — the commit loop only
	 *  takes done cells, so it stays in the live region); later calls of
	 *  the SAME turn MUTATE that block in place — same position, same
	 *  height, zero committed rows (the W8 fixed-window rule generalised
	 *  to state). An unchanged whole-table replace (the task extension's
	 *  idempotent shape) is a no-op — no mark, no frame. The block commits
	 *  ONCE at the turn's end (endTurn); the next turn's first call starts
	 *  a fresh block — one settled block per turn that touched the list,
	 *  never one per update. The pipe path stays per-call (byte-linear —
	 *  every write is final; there is no in-place redraw in a pipe). */
	checklist(header: string, items: { text: string; status: "pending" | "active" | "done" }[]): void {
		if (!this.#isActive()) {
			this.#closeOpenThinking();
			this.#closeOpenText();
			const p = palette();
			this.#write(`${p.bold}✦${p.reset} ${escapeTerminal(header)}\n`);
			const glyphOf = (status: string): string => (status === "pending" ? "□" : status === "active" ? "▖" : "▣");
			for (const item of items) this.#write(`  ${glyphOf(item.status)} ${escapeTerminal(item.text)}\n`);
			return;
		}
		this.#closeOpenThinking();
		this.#closeOpenText();
		const turn = this.#turns.length - 1;
		const last = this.#cells[this.#cells.length - 1];
		if (last !== undefined && last.kind === "checklist" && !last.done && last.turn === turn) {
			// TV-1B: the header participates in the change detection — the
			// settle verdict is a header-only update over the same items,
			// and an items-only guard would swallow it silently.
			if (last.header !== header || !sameTask(last.items, items)) {
				Object.assign(last, { header, items });
				this.#mark();
			}
			return;
		}
		this.#cells.push({
			kind: "checklist",
			header,
			items,
			done: false,
			expanded: false,
			startedAt: Date.now(),
			durationSeconds: 0,
			turn,
		});
		this.#mark();
	}

	/** The startup banner (W1): a LIVE cell — the tier re-derives per
	 *  frame (bannerLines with the CURRENT W and H), so a resize re-tiers
	 *  the art instead of re-folding frozen rows (a window below 40 cols
	 *  never paints the logo). W5: the resume metas ride the cell — the
	 *  list re-gates with the tier (BIG only) and re-times with the
	 *  frame. The inactive path keeps the historical bytes (no resume —
	 *  the pipe contract). */
	banner(version: string, extensionsText: string, resume: ResumeMeta[] = [], meta?: BannerMeta | undefined): void {
		if (!this.#isActive()) {
			this.#closeOpenThinking();
			this.#closeOpenText();
			const W = this.#opts.width() || 80; // a 0-size pty falls back
			const H = this.#opts.height();
			const p = palette();
			for (const r of bannerLines(W, H, version, extensionsText, [], Date.now(), meta)) this.#write(`${p.dim}${r}${p.reset}\n`);
			this.#write("\n");
			return;
		}
		this.#closeOpenThinking();
		this.#closeOpenText();
		this.#cells.push({ kind: "banner", version, extensionsText, resume, meta, done: true });
		this.#mark();
	}

	raw(lines: string[], wrap?: "words"): void {
		if (!this.#isActive()) {
			this.#closeOpenThinking();
			this.#closeOpenText();
			for (const line of lines) this.#write(`${line}\n`);
			return;
		}
		this.#closeOpenThinking();
		this.#closeOpenText();
		this.#cells.push({ kind: "raw", lines, done: true, ...(wrap === undefined ? {} : { wrap }) });
		this.#mark();
	}

	/** The last COMPLETE thinking block, for /think. */
	lastThinking(): string | null {
		return this.#lastThinking;
	}

	/** The last completed tool call, for /last. */
	lastTool(): { name: string; input: Record<string, unknown>; result: { content: string; isError: boolean } } | null {
		return this.#lastTool;
	}

	/* DECLARED REVERSAL (D-S2-1, owner-ruled 2026-09-06): `#focusIndex`
	   stood here — TUI2-R2 ⑤'s bright ctrl+o token on the newest live
	   card, "the cell the next press will act on". DC-50 made ctrl+o a
	   global switch, so there was no target left for a marker to name;
	   the status row's idle hint names the switch instead (#statusSource). */

	/**
	 * R4 (C4d) — `/rewrap`: the recent PROSE, re-rendered at the current
	 * width and APPENDED at the bottom. Committed rows carry no soft-wrap
	 * flag (autowrap is OFF; every row is painted or scrolled out by a
	 * bare LF), so the terminal cannot reflow them itself. R14
	 * (ADR-0046 Amendment 1, D-B3) made a settled resize reprint the
	 * whole session from the model on its own; this stays as the
	 * user-invoked form, and it still appends rather than erasing —
	 * nothing above the append is rewritten.
	 *
	 * Scoped to PROSE. Text is what reads badly at the wrong width — a
	 * paragraph folded for 120 columns and read at 60 is the complaint.
	 * Cards and chips are short and carry their own width ladders.
	 */
	rewrap(): { lines: string[]; blocks: number; skipped: number } {
		const W = this.#opts.width();
		const H = this.#opts.height();
		const ctx: FrameCtx = { spinnerI: this.#spinnerI, now: Date.now(), height: H };
		// two screens is the bound: enough to re-read what a resize just
		// made awkward, short enough that the append is not its own wall
		// of text. A silent cap would read as "this is all of it".
		const budget = Math.max(H, 2 * H);
		const chunks: string[][] = [];
		let rows = 0;
		let blocks = 0;
		let skipped = 0;
		for (let i = this.#committed - 1; i >= 0; i -= 1) {
			const cell = this.#cells[i]!;
			if (cell.kind !== "md") continue;
			blocks += 1;
			if (rows >= budget) {
				skipped += 1;
				continue;
			}
			const lines = cellComponent(cell).render(W, ctx);
			chunks.unshift(lines);
			rows += lines.length;
		}
		return { lines: chunks.flat(), blocks: blocks - skipped, skipped };
	}
	/* R13 — `#foldBody` retired with the segment fold: with nothing
	   folded there is no body a fold stands for. */


	// ─── R5: the transcript viewer ──────────────────────────────────
	//
	// The viewer occupies the LIVE REGION, exactly as the keys sheet
	// does. It is not the alternate buffer and never will be: while an
	// overlay is up the window is frozen, no LF is emitted, nothing
	// enters the scrollback, and the close takes the full-redraw path
	// and restores every displaced row (TUI2-R1.5 7(a), and its gate).

	/** Whether the viewer owns the live region right now. */
	viewerOpen(): boolean {
		return this.#viewer !== null;
	}

	/** ctrl+r — open on the newest fold, or close. */
	viewerToggleMode(): void {
		if (this.#viewer !== null) {
			this.#viewer = null;
		} else {
			const ctx: FrameCtx = { spinnerI: this.#spinnerI, now: Date.now(), height: this.#opts.height() };
			this.#viewer = viewerInit(this.#viewerEntries(this.#opts.width(), ctx));
		}
		this.#mark();
	}

	/** The viewer's keys. Everything the surface can do, a key does —
	 *  there is no pointer, so there is nothing a pointer could reach
	 *  that a keyboard cannot. */
	viewerKey(cmd: "up" | "down" | "toggle" | "all" | "pageUp" | "pageDown" | "home" | "end"): void {
		if (this.#viewer === null) return;
		const W = this.#opts.width();
		const ctx: FrameCtx = { spinnerI: this.#spinnerI, now: Date.now(), height: this.#opts.height() };
		const entries = this.#viewerEntries(W, ctx);
		const rows = this.#viewerBandRows();
		const s = this.#viewer;
		switch (cmd) {
			case "up":
				this.#viewer = viewerMove(entries, s, -1, rows);
				break;
			case "down":
				this.#viewer = viewerMove(entries, s, +1, rows);
				break;
			case "home":
				this.#viewer = viewerMove(entries, s, -entries.length, rows);
				break;
			case "end":
				this.#viewer = viewerMove(entries, s, entries.length, rows);
				break;
			case "pageUp":
				this.#viewer = viewerScroll(entries, s, -rows, rows);
				break;
			case "pageDown":
				this.#viewer = viewerScroll(entries, s, rows, rows);
				break;
			case "toggle":
				this.#viewer = viewerToggle(entries, s, rows);
				break;
			case "all":
				this.#viewer = viewerToggleAll(entries, s, rows);
				break;
		}
		this.#mark();
	}

	/** How many rows the viewer's LIST gets: the content cap, less its
	 *  own title and hint rows. */
	#viewerBandRows(): number {
		const H = this.#opts.height();
		const W = this.#opts.width();
		const queueRows = this.#queueRows(W, H);
		const inputExtra = this.#inputRows(W, H, this.#menuRows(W).length, queueRows.length).rows.length - 1;
		return Math.max(1, H - 4 - inputExtra - queueRows.length - 2);
	}

	/**
	 * The expandable things in the transcript, oldest first.
	 *
	 * The set is `#collapsed` — the SAME ring `ctrl+o` walks — so the two
	 * mechanisms can never disagree about what is reachable. The ring is
	 * newest-first (it is unshifted on commit); reading order is the
	 * other way, so it is reversed here.
	 *
	 * Every entry is rendered at the CURRENT width, which is what makes
	 * this surface the answer to "I resized and want to re-read the
	 * history": the scrollback copy stays the immutable original at its
	 * original widths, and this is where you go to read it at today's.
	 */
	#viewerEntries(W: number, ctx: FrameCtx): ViewerEntry[] {
		const inner = Math.max(1, W - VIEWER_GUTTER);
		const out: ViewerEntry[] = [];
		for (const idx of [...this.#collapsed].reverse()) {
			const cell = this.#cells[idx];
			if (cell === undefined) continue;
			// R13 — the viewer's FOLD entry retired with the fold: every
			// entry is now a card, and a card's entry is its own full body.
			if (cell.kind !== "tool") continue;
			// the tool card's FULL body — the same rows its own ctrl+o
			// opens. The expanded flag is saved and restored inside this
			// synchronous call; it never outlives the render, so the
			// committed geometry #committedLines derives can never see it.
			const saved = cell.expanded;
			cell.expanded = true;
			const rows = cellComponent(cell).render(inner, ctx);
			cell.expanded = saved;
			// DC-56 (owner, 2026-09-09): the head is the first row that SAYS
			// something. R13's card wears a washed PAD row above its head on
			// the palettes with a real background (light, dark) and none under
			// the neutral reverse-video wash — so `rows[0]` was the head on
			// one palette and a blank washed row on the others, and ctrl+r on
			// a light terminal showed "5 folds" over five empty grey rows.
			const first = rows.findIndex((r) => saysSomething(r));
			const headAt = first < 0 ? 0 : first;
			out.push({ head: rows[headAt] ?? "", body: rows.slice(headAt + 1) });
		}
		return out;
	}

	/** The viewer's band: its title, its list, its keys. */
	#viewerBand(W: number): string[] {
		if (this.#viewer === null) return [];
		const p = palette();
		const ctx: FrameCtx = { spinnerI: this.#spinnerI, now: Date.now(), height: this.#opts.height() };
		const entries = this.#viewerEntries(W, ctx);
		const rows = this.#viewerBandRows();
		const title = viewerTitle(entries);
		const shown = viewerRows(entries, this.#viewer, W, rows);
		const flat = viewerFlat(entries, this.#viewer).length;
		const more = flat > rows ? ` · ${this.#viewer.top + 1}-${Math.min(flat, this.#viewer.top + rows)} of ${flat}` : "";
		// the rule is MEASURED, not over-generated and cut — a title row
		// ending in `…` says the title was truncated, which it was not.
		const label = `── ${escapeTerminal(title)}${more} `;
		const fill = "─".repeat(Math.max(0, W - visibleWidth(label)));
		return [
			cutLine(`${p.dim}${label}${fill}${p.reset}`, W),
			...shown,
			cutLine(`${p.dim} ${viewerHint(this.#viewer, entries)}${p.reset}`, W),
		];
	}

	/* DECLARED REVERSAL (DC-50 / R14, 2026-09-05): the APPENDED expansion
	   stood here — `expandNext`, `#expandNextRaw`, `#lastAppend`, the
	   `#opened` set. ADR-0046 §3 forbade re-rendering a committed card,
	   so the only way to show a body was to print a copy further down.
	   Amendment 1 lets a settled reprint re-render every card where it
	   stands, and `toggleExpanded` is the whole feature. `#collapsed`
	   stays: the viewer (ctrl+r) reads it as its index of cut cells. */

	// ---- the Dock façade (the CLI's chrome API — same shape as the old dock) ----

	/** Docked = the chrome is live (a color TTY with a real size). */
	get active(): boolean {
		return this.#docked && this.#isActive();
	}

	/** TUI2-R2pre ③ — the ONE place a resize listener is installed, and it
	 *  removes the previous one first. `process.stdout` is process-wide and
	 *  its listeners outlive the object that added them, so "add" without
	 *  "remove first" is a leak by construction: the old closure is
	 *  unreachable the moment #resizeHandler is overwritten, and not even
	 *  exit() can take it off. */
	#attachResize(): void {
		this.#detachResize();
		this.#resizeHandler = () => this.onResize();
		process.stdout.on("resize", this.#resizeHandler);
	}

	#detachResize(): void {
		if (this.#resizeHandler === null) return;
		process.stdout.off("resize", this.#resizeHandler);
		this.#resizeHandler = null;
	}

	enter(): void {
		const rows = process.stdout.rows ?? 0;
		if (process.stdout.isTTY !== true || palette().bold === "" || rows < 4) return;
		this.#docked = true;
		this.#guardOutput();
		// REL-0152-D19: RELEASE the terminal we were handed, before the
		// first frame.
		//
		// The dock resets on the way OUT and reset nothing on the way IN,
		// so every session began in whatever state the previous occupant
		// left. For THIS product that is not an edge case: kiso's claim is
		// that it survives kill -9, which makes "the last instance died
		// without running its teardown" a supported and advertised way to
		// arrive here.
		//
		// Both of these confine writes to a SUB-REGION of the screen,
		// which is the only way content can survive at a column the dock
		// paints — every chrome row is exactly W wide and written from
		// column 1, so an erase plus a W-wide write covers the row end to
		// end unless the write cannot reach the ends.
		//
		//   ESC[r     the scroll region back to the whole screen
		//   ESC[?69l  left/right margin mode OFF (DECLRMM) — ESC[r does
		//             NOT release margins, which is why resetting only the
		//             region on exit was never enough
		//
		// And two that a KILLED kiso leaves set, which REL-0152-D14
		// introduced and this is the first thing to defend against it: a
		// frame turns autowrap off and the cursor invisible and restores
		// both at its end, so a process that dies BETWEEN those two points
		// hands the shell — and the next kiso — a terminal with wrapping
		// off and no cursor. `kill -9` cannot be caught, so the entry is
		// the only place this can be repaired, and a product whose claim
		// is that it survives kill -9 has to repair it there.
		//
		//   ESC[?7h   autowrap back to its default
		//   ESC[?25h  the cursor visible again
		//
		// Idempotent, sixteen bytes, once per session, and correct whether
		// or not anything was actually left set.
		this.#needsReset = true;
		this.#attachResize();
		this.#fullRedraw = true;
		this.#dirty = true;
		this.render(); // the FIRST frame — the full-redraw path, no pre-clear
	}

	/** Teardown — CSI r (the "no broken terminal" contract byte), the
	 *  chrome rows cleared, the cursor home at the input line. */
	exit(): void {
		this.#unguard?.();
		// REL-0152-D18: a drag in flight must not repaint into a torn-down
		// dock — the timer outlives the compositor otherwise.
		if (this.#resizeTimer !== null) {
			clearTimeout(this.#resizeTimer);
			this.#resizeTimer = null;
		}
		this.#resizePending = false;
		// TUI2-R3v2 ②: the mouse disable rides the SAME teardown as CSI r,
		// and rides it BEFORE the docked guard — an un-docked compositor is
		// exactly the state a superseded or half-torn-down one is in, and
		// that is when a leak survives. The editor disables it too; this is
		// the second belt on the one contract the round calls blocker-class.
		//
		// TTY-GATED, and the gate is not a nicety. A pipe has no mouse mode
		// to reset, so the bytes would be pure noise there — and the pipe
		// path is byte-identical by ruling. The unguarded version put
		// "[?1000l[?1006l" into piped stdout and four gates caught it
		// (compact-cli, tui-modes, tui-v7-planmode, tui2-r2-resume-picker):
		// the invariant is about terminals, and a pipe is not one.
		// REL-0152-D14: autowrap goes back on with the mouse, and for the
		// same reason — the terminal outlives kiso, and a mode kiso turned
		// off inside a frame must never be what the shell inherits. The
		// frame restores it itself; this is the second belt, on the same
		// TTY gate, because a half-torn-down compositor is exactly where a
		// mode leak survives.
		if (process.stdout.isTTY === true) this.#write(`${MOUSE_OFF}\x1b[?7h`);
		if (!this.#docked) {
			// TUI2-R2pre ③: an un-docked compositor can still hold a listener
			// (it was superseded, or enter() ran and the dock was torn down by
			// another path) — the teardown is unconditional, the CHROME clear
			// below is not.
			this.#detachResize();
			return;
		}
		this.#docked = false;
		this.#detachResize();
		const H = this.#lastH > 0 ? this.#lastH : process.stdout.rows ?? 24;
		const out: string[] = [];
		out.push("\x1b[r");
		// V6-3 + KC1: the chrome rows — the RECORDED composer extent rides
		// the same mechanism the resize clear already uses (N = 1 ⇒ H−3..H)
		for (let row = H - 2 - this.#lastInputRows; row <= H; row += 1) {
			out.push(`\x1b[${row};1H\x1b[0K`); // clear the chrome rows
		}
		out.push(`\x1b[${Math.max(1, H - 1)};1H`);
		this.#write(out.join(""));
	}

	/**
	 * REL-0152-R1 — the compositor is not the only writer, and a diff has
	 * to know.
	 *
	 * The old renderer repainted every row of every frame, so anything
	 * else that printed to the terminal was corrected within one frame
	 * and nobody had to think about it. A diff writes only what changed,
	 * so an outside write leaves the held screen describing a terminal
	 * that no longer exists — and the next frame skips exactly the rows
	 * it should have repaired.
	 *
	 * That is not hypothetical: a bare `console.log` in the CLI's boot
	 * path prints the faux-mode notice with a trailing newline, which
	 * SCROLLS the terminal two rows while the dock is up. The chrome then
	 * sits two rows above where the model puts it, the diff sees no
	 * change, and the cursor parks on the wrong row. Three PTY gates
	 * caught it.
	 *
	 * REL-0152-D17: BOTH descriptors, and the second one is the one that
	 * mattered. The first version of this guard wrapped stdout alone,
	 * while kiso's degradation notices go to stderr through
	 * `console.error` — and several of them BEGIN with `[` and contain
	 * `]`:
	 *
	 *     [extensions] …        [project .kiso] …
	 *     [KISO_FAUX_SCRIPT] …  [run failed] …
	 *
	 * Those land on the tty wherever the cursor is, and a renderer that
	 * does not know they were printed skips exactly the rows that would
	 * repair them. The residue survives on the rows whose desired content
	 * NEVER changes — the composer box's own edges — which is a stray `[`
	 * at the left and `]` at the right for the rest of the session,
	 * clearing only on a resize and returning on the next launch.
	 *
	 * The reasoning that missed it was mine, and it is worth keeping: the
	 * renderer emits no OSC and no bare `]`, so a `]` on screen CANNOT
	 * have come from its stream. I had that fact and concluded "therefore
	 * the terminal invents it" when the only sound conclusion is
	 * "therefore something else wrote it".
	 *
	 * The fix is not a list of writers to remember, and not silencing the
	 * loggers. A compositor cannot hold a belief about a terminal it does
	 * not own: any write it did not make forgets the screen, whichever
	 * descriptor carried it. New callers cannot get it wrong because they
	 * are not asked to get it right.
	 */
	#guardOutput(): void {
		if (this.#unguard !== null || this.#opts.write !== undefined) return;
		const restores: (() => void)[] = [];
		for (const stream of [process.stdout, process.stderr]) {
			const real = stream.write.bind(stream);
			const patched = ((chunk: string | Uint8Array, ...rest: unknown[]): boolean => {
				if (!this.#inFrame) this.#screen = [];
				return (real as (...a: unknown[]) => boolean)(chunk, ...rest);
			}) as typeof stream.write;
			stream.write = patched;
			restores.push((): void => {
				// only restore what we installed — another wrapper may have
				// been layered on top since (the byte trace does exactly that)
				if (stream.write === patched) stream.write = real;
			});
		}
		this.#unguard = (): void => {
			for (const r of restores) r();
			this.#unguard = null;
		};
	}

	/** TUI2-R3v2 ②: the panel's option rows as this frame placed them —
	 *  absolute, 1-based. The click hit-test's single source. */
	panelOptionRows(): { top: number; count: number; first: number } | null {
		return this.#panelRowSpan;
	}

	/** SIGWINCH: clear the OLD live area (recorded geometry, ED only —
	 *  zero LF, zero \x1b[3J — the shell history untouched), then the
	 *  full-redraw path at the NEW geometry (O(height), zero replay).
	 *  The clear starts at the ON-SCREEN live top (the bottom-anchored
	 *  live region's first row) — NEVER at the formula's committed-count
	 *  top: external writes (the CLI's console.error CRLF) can shift the
	 *  committed content down, and a formula-top ED0 would clear it. */
	/**
	 * REL-0152-D18 — a window DRAG is one resize, not forty.
	 *
	 * SIGWINCH fires continuously while a drag is in progress — every few
	 * pixels is another signal — and this used to answer each one at once
	 * with an erase and a full repaint. A real terminal REFLOWS on a width
	 * change and pushes the rows it displaces into its scrollback, so
	 * every one of those repaints deposited another copy of the screen
	 * into the history. The owner's two-second drag left six identical
	 * copies of the same tool block in the transcript.
	 *
	 * Nothing clever can undo that afterwards: the scrollback is not ours
	 * to rewrite. The only fix is to not paint into the middle of a drag.
	 *
	 * The geometry is adopted IMMEDIATELY — every cap and bound is read
	 * from `#opts` at frame time, so the model is already at the new size
	 * and nothing is computed against a stale width. What waits is the
	 * PAINT. When the signals stop, one erase and one repaint.
	 *
	 * The competitor does not have this problem, for a structural reason
	 * worth naming rather than envying: it runs on the alternate screen,
	 * which has no scrollback to accumulate into. kiso is on the primary
	 * screen deliberately — the transcript IS the terminal's own
	 * scrollback, which is the product's whole claim — so it pays for
	 * that choice here, and has to pay carefully.
	 */
	onResize(): void {
		if (!this.#isActive()) return;
		// R14 — the FIRST winch of a storm snapshots what the terminal is
		// currently holding. A drag fires many winches; the settle must
		// compare its end against the storm's beginning, not against the
		// previous winch.
		if (!this.#resizePending) {
			this.#winchFromW = this.#paintedW;
			this.#winchFromH = this.#paintedH;
		}
		this.#resizePending = true;
		if (this.#resizeTimer !== null) clearTimeout(this.#resizeTimer);
		this.#resizeTimer = setTimeout(() => {
			this.#resizeTimer = null;
			this.#settleResize();
		}, RESIZE_SETTLE_MS);
		if (this.#resizeTimer.unref !== undefined) this.#resizeTimer.unref();
	}

	/**
	 * DC-3 — the ground arrived, so every colour on the held screen is
	 * stale.
	 *
	 * The terminal answers `OSC 11` a few milliseconds after startup, by
	 * which time the first frame is already painted with the no-ground
	 * palette. Rather than delay the opening to wait for an answer that
	 * may never come, the frame is painted at once and repainted when the
	 * answer lands. Invalidating the held screen is exactly what a resize
	 * does, for exactly the same reason — every row's bytes are wrong —
	 * so it rides the settle the resize already owns and costs one
	 * repaint, once per session.
	 */
	onGroundChange(): void {
		this.#screen = [];
		this.onResize();
	}

	/**
	 * R14 / route B — THE ONE REPAINT A DRAG EARNS IS A REPRINT.
	 *
	 * It used to be `ESC[from;1H ESC[0J` — erase from the recorded live
	 * top down, then redraw the live area, leaving the committed rows
	 * above to whatever the terminal's own reflow had made of them. That
	 * is the shape R10 measured on the owner's real terminal, and it
	 * lost: a grow dropped 16 rows of history (DC-39), a narrow
	 * duplicated four tokens, and the scrolled-off transcript never
	 * reflowed at all. All three are one fault — kiso doing window
	 * arithmetic over rows the terminal had already reflowed underneath
	 * it, with `#scrolledOff` carried across a fold change that makes
	 * every index mean something else.
	 *
	 * So it stops arguing. `2J H 3J` — erase screen, home, erase
	 * scrollback, in THAT order because on Apple Terminal a bare `2J`
	 * scrolls the screen into history and only the following `3J` makes
	 * the state clean — and then the whole committed transcript is
	 * reprinted at the new geometry through the path a fresh terminal
	 * already uses. The terminal ends holding exactly one rendering.
	 *
	 * The declared cost (ADR-0046 Amendment 1): everything the terminal
	 * held before kiso started is erased at the first resize. Measured
	 * on the reference implementation as 0/60 in every direction — this
	 * is the behaviour being adopted, not a regression. kiso's own
	 * record is untouched: the session log holds it, `--resume` replays
	 * it, and G4' asserts the 0/60 so the cost cannot drift silently.
	 *
	 * D-B2: EVERY settled resize reprints, height-only included. A
	 * SIGWINCH at the same geometry emits nothing at all.
	 */
	#settleResize(): void {
		if (!this.#resizePending || !this.#isActive()) return;
		this.#resizePending = false;
		const H = this.#opts.height();
		const W = this.#opts.width();
		// D-B2's other half: a winch that did not change the geometry is
		// not a resize. Emitting the erase for it would throw away the
		// terminal's scrollback for nothing (the V6-1 idempotence case).
		if (this.#winchFromW === W && this.#winchFromH === H) return;
		// §9.2 — the viewer is closed first. Nothing commits while it is
		// up and a reprint is a commit storm; the user reopens it. One
		// keypress, stated rather than hidden.
		if (this.#viewer !== null) {
			this.#viewer = null;
			this.#viewerWasUp = true;
		}
		this.#reprint();
	}

	/**
	 * R14 — ERASE THE TERMINAL AND PRINT THE SESSION AGAIN.
	 *
	 * Four callers now: a settled resize, DC-50's ctrl+o, §2.3's ctrl+t,
	 * and §2.4's return from an external editor. They are the same act —
	 * the rendering the terminal holds is wrong (wrong geometry, wrong
	 * expansion state, wrong fold, or another program drew over it) and
	 * the model is the only authority on what it should be — so they
	 * share the path rather than growing four.
	 */
	#reprint(): void {
		const H = this.#opts.height();
		this.#write("\x1b[2J\x1b[H\x1b[3J");
		// The terminal now holds nothing, so every record of what it held
		// is void. `#scrolledOff` is the frontier of what reached its
		// scrollback: after the erase, that is zero — which is also what
		// releases the committed cells to be re-rendered at the new width
		// without contradicting anything, the thing DC-34's frontier rule
		// existed to prevent.
		this.#scrolledOff = 0;
		for (let i = 0; i < this.#committed; i += 1) this.#lineCache[i] = null;
		this.#screen = new Array(Math.max(1, H)).fill(NOT_PAINTED);
		this.#cursorRow = 1;
		this.#fullRedraw = true;
		this.#resizeFrame = true;
		this.#dirty = true;
		this.render();
	}

	/**
	 * DC-50 — ctrl+o flips ONE switch, and every settled card obeys it.
	 *
	 * The walk this replaces existed because ADR-0046 §3 forbade
	 * re-rendering a committed card, so the only way to show one's body
	 * was to APPEND a copy further down — with a ring to decide which
	 * card was next, `#opened` to keep the ring from repeating, and
	 * `#lastAppend` to stop a held key printing the same rows three times
	 * (DC-35). Amendment 1 removes the premise: the scrollback is ours to
	 * erase, so a card can simply be re-rendered where it stands.
	 *
	 * A RUNNING card is exempt. Its height is E2/DC-43's — it grows from
	 * its own content — and a global "show everything" has no business
	 * reaching into a card whose content is still arriving.
	 */
	toggleExpanded(): void {
		this.#expandedAll = !this.#expandedAll;
		for (const cell of this.#cells) {
			// SETTLED CONTENT, not "done". A card parked for approval is
			// `state: "approval"`, `done: false` — and its content is not
			// still arriving: the diff is complete and the card is waiting
			// for a human to read it and decide. The mechanism this
			// replaces toggled it (any state but "pending"), and the
			// dispatch comment said why: "the approval pause is exactly
			// when the user reads a cut diff, and the key must answer then,
			// never after the run." A `done`-only switch answers with
			// nothing at the one moment the answer matters most.
			//
			// The exemption is for the card still GROWING — E2 and DC-43
			// own its height, and a global "show everything" has no
			// business reaching into content that is still arriving. That
			// is the ruling's reason; `done` alone was its wording.
			if (cell.kind !== "tool") continue;
			if (cell.done || cell.state === "approval") cell.expanded = this.#expandedAll;
		}
		this.#reprint();
	}

	/** §2.4 — the terminal holds someone else's drawing (an external
	 *  editor had it) and the model is the only authority on what should
	 *  be there. The same act as a resize; the same path. */
	reprint(): void {
		this.#reprint();
	}

	/** DC-50 — the switch itself, for the CLI's affordance text. */
	expandedAll(): boolean {
		return this.#expandedAll;
	}

	/** §2.3 — ctrl+t: the committed thinking blocks fold, and fold back.
	 *
	 *  DC-50's mechanism exactly: one boolean, then the session is printed
	 *  again, so the blocks ALREADY on screen obey the switch rather than
	 *  only the next ones. Nothing durable moves — the events are
	 *  untouched and `/think` still reaches the last block whole.
	 *
	 *  COMMITTED blocks only. The live `thinking…` placeholder belongs to
	 *  the live region, not to a cell, and an OPEN thinking cell is text
	 *  still arriving; a global "quiet down" has no business reaching into
	 *  either, which is the same exemption `toggleExpanded` states for a
	 *  card that is still growing. */
	toggleThinking(): void {
		this.#thinkingFolded = !this.#thinkingFolded;
		for (const cell of this.#cells) {
			if (cell.kind === "thinking" && cell.done) cell.folded = this.#thinkingFolded;
		}
		this.#reprint();
	}

	/** W18: the status row's right-aligned hint is part of the status
	 *  state — the compacting row passes "esc to cancel" (the affordance
	 *  must survive repaints). */
	setStatus(text: string, hint: string | null = null): void {
		this.#status = text;
		this.#statusHint = hint;
		this.redraw();
	}

	setTail(tail: string): void {
		this.#tail = tail;
		this.redraw();
	}

	/** The status row's source — W21: while a panel is up, the panel's
	 *  phase status + affordance REPLACE the CLI's painting status (the
	 *  compositor derives both from the bound panel state; the old
	 *  question slot's dim-pending shape is the normal branch's shape
	 *  now). */
	#statusSource(): { status: string; hint: string | undefined; expand: "expand all" | "collapse all" | null } {
		const panel = this.#panelState?.() ?? null;
		// DC-38: the panel's STATUS replaces the CLI's painting status —
		// that half of W21 stands. The HINT does not come with it, because
		// the panel block already ends in its own affordance row and has
		// since TUI2-R1.5 ("the affordance — the phase's key hint, ONE
		// row"). Both sites read `panelAffordance`, neither knew about the
		// other, and an approval at W≥100 printed the same 48-cell sentence
		// twice, six rows apart.
		//
		// The block's copy is the one to keep, on two grounds. It sits next
		// to the options it names. And it never disappears: the status row
		// drops its hint when the left text plus the hint will not fit, so
		// the duplicate was width-dependent — one copy on an ask (long left
		// text), two on an approval (`❯ run paused`, twelve cells) — which
		// is why every fixed-width gate was blind to it. Each flavour's
		// block carries its own row (approval-panel.ts pushes it for the
		// approval and the pick, ask-panel.ts for the ask), so nothing is
		// lost anywhere.
		if (panel !== null) return { status: panelStatusOf(panel), hint: undefined, expand: null };
		// W22: while turns wait in the queue, the right hint shows the
		// count — the chips below carry the lines themselves.
		const queued = this.#queueState?.().length ?? 0;
		if (queued > 0) return { status: this.#status, hint: `+${queued} queued`, expand: null };
		// D-S2-1 (owner-ruled 2026-09-06): the idle hint names the ctrl+o
		// SWITCH — `expand all` or `collapse all` by its state — and only
		// while a committed card has something behind the key (#collapsed
		// is the index of exactly those). A hint for a key that would
		// change nothing is a hint that lies. This replaced the per-card
		// bright token (TUI2-R2 ⑤), which had no single target left to
		// mark once DC-50 made the key global.
		const expand = this.#collapsed.length > 0 ? (this.#expandedAll ? "collapse all" : "expand all") : null;
		return { status: this.#status, hint: this.#statusHint ?? undefined, expand };
	}

	/** Bind the editor's panel state — the PanelSelect slot occupant
	 *  (W21: the panel replaces the live region + the input lead while
	 *  up; the old ApprovalPrompt's question slot retires with it). */
	bindApproval(state: () => PanelState | null): void {
		this.#panelState = state;
	}

	/** Bind the CURRENT input line's state — the focus component reads it. */
	bindInput(state: () => InputState, prompt: string): void {
		this.#inputState = state;
		this.#inputPrompt = prompt;
	}

	/** Bind the editor's slash-command menu state — the MenuSelect slot
	 *  occupant (the menu replaces the editor's view while open). */
	/** TUI2-R1 (D): bind the editor's keys-sheet flag. */
	bindSheet(state: () => boolean): void {
		this.#sheetState = state;
		this.#mark();
	}

	bindMenu(state: () => { items: readonly MenuItem[]; selected: number } | null): void {
		this.#menuState = state;
	}

	/** KC3 §4: bind the editor's @ file picker. It shares the menu's
	 *  band — see #menuRows for why that is a decision and not a
	 *  shortcut. */
	bindAt(state: () => AtPanelState | null): void {
		this.#atState = state;
	}

	/** TUI2-R2 ②: bind the editor's session picker — the band's third
	 *  occupant (see #menuRows for why they share one). */
	bindPick(state: () => SessionPickState | null): void {
		this.#pickState = state;
	}

	/** Bind the pending-turn queue — the CLI's live slots (chat.ts):
	 *  the chips render in the menu-rows family, the live caps shrink
	 *  by their rows, and the +N queued hint rides the status row. */
	bindQueue(state: () => readonly string[]): void {
		this.#queueState = state;
	}

	/** The input line's edit column — the old dock's API. v6: the CURSOR
	 *  derives from the frame's marker; this is the same value computed
	 *  from the bound input state (the CLI's BodyOptions.editCol callback
	 *  reads it — the marker math never desyncs by construction). */
	editCol(): number {
		const st = this.#inputState();
		const panel = this.#panelState?.() ?? null;
		// W23: the frame-derived column — wallL + leadWidth(lead) + cells
		// + 1 — the SAME formula the marker embeds at (the panel lead when
		// the panel owns the row; the old prompt-only math desynced the
		// panel rows' edit column; leadWidth is the ONE authority).
		// R2: wallL is 0 — the box is retired, so the row starts at column
		// one and the frame's marker and this formula share the constant.
		const lead = panel !== null ? panelLeadOf(panel) : this.#inputPrompt;
		return 1 + leadWidth(lead) + st.cursor;
	}

	/** The old dock's redraw — the editor's onRender target: mark + the
	 *  scheduler (16ms coalescing — the old sync draw coalesces the same). */
	redraw(): void {
		if (!this.#isActive()) return;
		this.#dirty = true;
		this.#scheduleFrame();
	}

	// ---- the scheduler (event-driven; zero heartbeat timers) ----

	#mark(): void {
		if (!this.#isActive()) return;
		this.#dirty = true;
		this.#scheduleFrame();
	}

	#scheduleFrame(): void {
		if (this.#frameTimer !== null) return;
		this.#frameTimer = setTimeout(() => {
			this.#frameTimer = null;
			if (this.#dirty) {
				this.#dirty = false;
				this.render();
			}
		}, this.#frameMs);
		this.#frameTimer.unref();
	}

	/**
	 * The spinner: a ONE-SHOT re-armed ONLY while something is MOVING —
	 * nothing moving → no timer → zero bytes (the #14/#15 contract,
	 * structural).
	 *
	 * R3: "moving" used to mean a running TOOL and nothing else. But the
	 * same counter drives the status row's `working` twinkle, and the
	 * model spends whole stretches thinking with no tool open at all —
	 * so the one indicator whose entire job is "I am still alive" froze
	 * solid exactly when the user most needed it to move. It was
	 * reported as "I thought it had failed", which is precisely the
	 * message a frozen liveness mark sends.
	 *
	 * An OPEN THINKING cell counts as movement now, and so does a tool
	 * parked at an approval — that one is waiting on a human rather than
	 * working, but the mark is still the proof the process is alive.
	 */
	#armSpinner(): void {
		if (this.#spinnerTimer !== null) return;
		this.#spinnerTimer = setTimeout(() => {
			this.#spinnerTimer = null;
			const moving = this.#cells.some(
				(c) =>
					(c.kind === "tool" && (c.state === "running" || c.state === "approval") && !c.done) ||
					(c.kind === "thinking" && !c.done),
			);
			if (moving) {
				this.#spinnerI = (this.#spinnerI + 1) % MOTION_FRAMES;
				this.#dirty = true;
				this.#scheduleFrame();
				this.#armSpinner();
			}
		}, SPINNER_MS);
		this.#spinnerTimer.unref();
	}

	/** Teardown — flush a pending frame, stop the timers. */
	close(): void {
		if (this.#frameTimer !== null) {
			clearTimeout(this.#frameTimer);
			this.#frameTimer = null;
		}
		if (this.#spinnerTimer !== null) {
			clearTimeout(this.#spinnerTimer);
			this.#spinnerTimer = null;
		}
		if (this.#dirty) this.render();
	}

	// ---- the one writer ----

	/**
	 * THE LIVE PROJECTION — the uncommitted cells as rows, one definition
	 * for the natural path and the force-commit loop alike (two copies of
	 * "what the live region looks like" would be two answers to one
	 * question). The live region is bounded by the SCREEN, and nothing
	 * else: DC-46's `#liveRoom` capped it at `H − chrome − #committedLines`
	 * to keep the window's top monotone, but `#committedLines` is
	 * cumulative, so one screenful into any session every running call
	 * was a head row with its output gone. The window's top is held by
	 * the `skip` clamp in render() instead; a live region that grows
	 * scrolls committed rows away, which is an append and not an un-scroll.
	 */
	#liveProjection(W: number, ctx: FrameCtx, cap?: number): string[] {
		const rows = this.#project(W, ctx, CAP_PREVIEW);
		if (cap === undefined || rows.length <= cap) return rows;
		// DC-43 / R13 E2 — THE WINDOW SHRINKS TO THE ROOM, one row at a
		// time, before any cell is force-committed. A running card that
		// could overflow the content cap would make the force-commit loop
		// push REAL cells into the scrollback to relieve rows that are, at
		// the bottom of a card's window, blank padding. So the cards give
		// way first, down to a single preview row, and then to their head
		// rows alone — the one form that fits anywhere.
		//
		// Committed cards are never trimmed: this is the LIVE projection,
		// and a row in the scrollback is final (§7.1).
		for (let n = CAP_PREVIEW - 1; n >= 1; n -= 1) {
			const tighter = this.#project(W, ctx, n);
			if (tighter.length <= cap) return tighter;
		}
		const heads = this.#project(W, ctx, 0);
		if (heads.length <= cap) return heads;
		// DC-53 — the LAST RESORT, and ONLY when the force-commit loop is
		// blocked. If the head of the queue can still be committed, this
		// projection must hand back everything it has: the loop counts its
		// rows to decide what to spill, and a truncated projection tells
		// it the region fits when it does not — which LOSES the rows it
		// would have committed (measured: a 40-line burst on a 12-row
		// screen kept 13 of them). Only a RUNNING CALL at the head makes
		// the loop unable to act, and only then is counting the tail the
		// honest thing left to draw.
		const head = this.#cells[this.#committed];
		if (head === undefined || head.kind !== "tool" || head.done) return heads;
		const keep = Math.max(1, cap - 1);
		const hidden = heads.length - keep;
		const p = palette();
		return [...heads.slice(0, keep), cutLine(`${p.dim}  +${hidden} more${p.reset}`, W)];
	}

	/**
	 * ONE PASS, AND EVERY CELL RENDERS ITSELF. The live form and the
	 * committed form are the same form, which is what makes a settle a
	 * change of content and never of position (DECLARED REVERSAL, R13:
	 * R3i's stretch line and R4's standing slot drew one line plus a
	 * fixed block for the whole stretch and had every other cell draw
	 * nothing; the owner ruled the summary costs more than it buys).
	 */
	#project(W: number, ctx: FrameCtx, budget: number): string[] {
		const out: string[] = [];
		const live: FrameCtx = { ...ctx, liveWindow: budget };
		let prev: string[] | null = this.#committed > 0 ? this.#lineCache[this.#committed - 1]! : null;
		for (let i = this.#committed; i < this.#cells.length; i += 1) {
			const rows = cellComponent(this.#cells[i]!).render(W, live);
			out.push(...this.#space(i, prev, rows));
			prev = rows;
		}
		// 0.24.2 ② — THE PLACEHOLDER. A turn in flight whose live region
		// has drawn nothing leaves the composer under a blank stretch,
		// with only the status row saying anything is happening; the owner
		// read that as the product having stopped.
		//
		// So one row says it: `thinking…`, dim italic at column 2, no
		// glyph — the SAME column and the same font a thinking paragraph
		// takes, so whatever arrives replaces it in place and the eye sees
		// a word change rather than a jump.
		//
		// It is NOT a cell. It never commits, never reaches the
		// scrollback, and neither `/last` nor the pipe has heard of it —
		// which is the whole of why a row that is a guess about the future
		// is allowed at all: a row that never becomes history cannot make
		// history wrong.
		if (out.length === 0 && this.#thinkingGap()) return [...bodySpacing(this.#committed > 0 ? this.#lineCache[this.#committed - 1]! : null, [thinkingRow()]) ];
		return out;
	}

	/** 0.24.2 ② — is this the gap the placeholder is for? A turn has
	 *  begun and not ended, and nothing else is drawing a live row (the
	 *  caller has already found the projection empty, which is what "no
	 *  card is running" reduces to once every cell renders itself). */
	#thinkingGap(): boolean {
		const turn = this.#turns[this.#turns.length - 1];
		if (turn === undefined || turn.ended) return false;
		// DC-53 — and NOTHING is in flight. The caller has already found
		// the projection empty, which used to be taken as "nothing is
		// happening"; it is also what a wrongly-committed running cell
		// leaves behind, and the placeholder then sat beside a call that
		// was running. An uncommitted cell is work in flight whether or
		// not it drew a row this frame.
		for (let i = this.#committed; i < this.#cells.length; i += 1) if (!this.#cells[i]!.done) return false;
		return true;
	}

	/** The live region's scalar — the unit tests assert the cap directly
	 *  (the e2e gate pins the screen consequence). W11: the formula's
	 *  blanks are join artifacts — the count includes them (they are real
	 *  screen rows), threaded against the previous sibling's OWN rows. */
	liveCount(): number {
		const W = this.#opts.width();
		const H = this.#opts.height();
		const chrome = this.#chrome(W, H);
		const ctx: FrameCtx = { spinnerI: this.#spinnerI, now: Date.now(), height: H };
		// DC-27 — the scalar measures what the SCREEN gets: the same
		// selector render() paints from, under the same chrome. A scalar
		// with rules of its own asserted a property of a function nothing
		// painted from, so the cap and geometry gates could not move on a
		// real regression ("the scalar must say so, or the cap arithmetic
		// disagrees with the screen" — TUI2-R1 D, R5, DC-27, one rule).
		return this.#liveRows(W, ctx, chrome.cap).lines.length + chrome.rows;
	}

	/** The lines committed THIS frame — the writes land in the frame's
	 *  committed section (the rows just above the live region). */
	#committedLinesThisFrame: string[] = [];
	// the CELL count when the frame began — the drawFull frozen bound's
	// unit (the cells committed BEFORE this frame; a force-commit frame's
	// placed LINES outnumber its cells)
	#committedAtFrameStart = 0;

	render(): void {
		if (!this.#isActive()) return;
		const H = this.#opts.height();
		const W = this.#opts.width();
		if (H < 4) return;
		this.#lastH = H;
		// R14 — the geometry THIS frame painted. `onResize` snapshots it
		// at the moment the winch arrives; see `#winchFromW`.
		this.#paintedW = W;
		this.#paintedH = H;
		const ctx: FrameCtx = { spinnerI: this.#spinnerI, now: Date.now(), height: H };
		if (this.#fullRedraw) this.#rederiveCommitted(W, ctx);
		// 1. the natural commits — the leading DONE cells freeze.
		this.#commitDone(W, ctx);
		// 2. the live lines — the unfinished cells (the tail) + the chrome.
		const chrome = this.#chrome(W, H);
		this.#noteOverlay();
		const live = this.#liveRows(W, ctx, chrome.cap);
		// 3. the FORCE commits — the live region's hard cap.
		const liveLines = this.#capLive(live.lines, W, ctx, chrome.cap);
		// 4. the geometry — the live region's first row:
		//    liveTop = min(totalCommitted, H - liveRows) + 1 — the screen
		//    shows the bottom H rows; the live region anchors to the bottom.
		const liveRowsTotal = liveLines.length + chrome.rows;
		const liveTop = Math.min(this.#committedLines, H - liveRowsTotal) + 1;
		// TUI2-R3v2 ②: the option rows' ABSOLUTE screen rows, recorded per
		// frame. A click is answered against the frame the human was looking
		// at when they clicked, which is this one.
		this.#panelRowSpan =
			live.panelSpan === null ? null : { top: liveTop + live.panelSpan.offset, count: live.panelSpan.count, first: live.panelSpan.first };
		// 5. the frame bytes.
		this.#paint(W, H, liveTop, liveLines, liveRowsTotal, chrome);
	}

	/** Phase 0 — a full redraw re-derives the committed rows from the
	 *  cache. A cell whose cache was invalidated (a settled resize, R14)
	 *  is rendered again at the current width; every other cell keeps
	 *  the rows it was committed with, because those rows are already
	 *  the terminal's (ADR-0046) and this frame paints the same bytes.
	 *
	 *  DECLARED REVERSAL (R14): DC-34's frontier-scoped REFOLD stood
	 *  here — a widen never refolded a committed cell, a narrowing
	 *  refolded the cells that no longer fit. Route B reprints the
	 *  whole session from the model on a settled resize, so no
	 *  committed row is refolded in place any more, and the width
	 *  guard that decided which ones were went with it. */
	#rederiveCommitted(W: number, ctx: FrameCtx): void {
		this.#committedLines = 0;
		for (let i = 0; i < this.#committed; i += 1) {
			const lines = this.#lineCache[i] ?? cellComponent(this.#cells[i]!).render(W, ctx);
			this.#lineCache[i] = lines;
			this.#committedLines += this.#space(i, i > 0 ? (this.#lineCache[i - 1] ?? []) : null, lines).length;
		}
	}

	/** Phase 1 — the natural commits: the leading DONE cells freeze —
	 *  their lines leave the live region, the scrolls + the committed
	 *  writes below place them (the #17 "freeze as a real line", short
	 *  sessions included — the frame coalescing keeps a cell's first
	 *  frame its freeze frame, so the frozen bytes emit exactly once). */
	#commitDone(W: number, ctx: FrameCtx): void {
		this.#committedAtFrameStart = this.#committed;
		this.#committedLinesThisFrame = [];
		while (this.#committed < this.#cells.length && this.#cells[this.#committed]!.done) {
			this.#commitCell(this.#committed, W, ctx);
		}
	}

	/** The chrome this frame wears: the menu band, the queue band (W22:
	 *  the menu-rows family's other occupant — the band above the box
	 *  top), the composer (KC1 §6: N rows; N = 1 ⇒ today's chrome
	 *  exactly — chromeRows = 3 + N + menu + queue, and the content cap
	 *  loses the composer's EXTRA rows the same way it loses the bands).
	 *  W11: the formula's blank above the first live cell hangs off the
	 *  last COMMITTED sibling (the join spans the boundary). */
	#chrome(W: number, H: number): Chrome {
		const menuRows = this.#menuRows(W);
		const queueRows = this.#queueRows(W, H);
		const editor = this.#inputRows(W, H, menuRows.length, queueRows.length);
		const inputExtra = editor.rows.length - 1;
		return {
			menuRows,
			queueRows,
			editor,
			inputExtra,
			rows: CHROME_ROWS + inputExtra + menuRows.length + queueRows.length,
			cap: H - 4 - inputExtra - queueRows.length,
		};
	}

	/** The overlay bookkeeping. TUI2-R1.5 ⑦(a) (VD-8): the sheet is an
	 *  OVERLAY, and the frame it opens on — and the one it closes on —
	 *  take the full-redraw path. The sheet REPLACES the live region, so
	 *  on an idle composer (where the live region is empty) opening it
	 *  GROWS the model by its own height; the frame's skip grows with it
	 *  and the difference is paid in real LFs — rows scrolled
	 *  permanently into the terminal's scrollback, which closing cannot
	 *  undo, because the scrollback is not ours to rewrite. Measured:
	 *  three rows per open on a full screen. The overlay displaces
	 *  content on screen instead. R5 — the viewer is an overlay of
	 *  exactly the same kind, so it joins the same flag. That one word
	 *  is what buys it the whole zero-litter discipline: the window
	 *  freezes, #emitScroll is skipped, and the close repaints from
	 *  #lastSkip. */
	#noteOverlay(): void {
		const sheetUp = this.#sheetState?.() === true;
		const viewerUp = this.#viewer !== null;
		this.#overlayFrame = sheetUp || this.#sheetWasUp || viewerUp || this.#viewerWasUp;
		this.#sheetWasUp = sheetUp;
		this.#viewerWasUp = viewerUp;
	}

	/** Phase 2 — ONE overlay selector: what occupies the live region
	 *  this frame. The transcript viewer (R5), the keys sheet (TUI2-R1
	 *  D) and the approval panel (W21) each REPLACE the live region —
	 *  it is what the human is reading right now — capped at the
	 *  content cap; the sheet and the viewer open only from an idle
	 *  composer, so neither can coexist with a panel. The panel also
	 *  reports where its clickable rows are (TUI2-R3v2 ②: the rows and
	 *  the span come from one call, so the hit-test reads the arithmetic
	 *  that placed the rows). Otherwise the projection of the live
	 *  cells. render() paints this and
	 *  liveCount() measures it — the same rows, by construction. */
	#liveRows(W: number, ctx: FrameCtx, cap: number): { lines: string[]; panelSpan: { offset: number; count: number; first: number } | null } {
		const capped = Math.max(1, cap);
		if (this.#viewer !== null) return { lines: this.#viewerBand(W).slice(0, capped), panelSpan: null };
		if (this.#sheetState?.() === true) return { lines: keysSheetRows(W).slice(0, capped), panelSpan: null };
		const panel = this.#panelState?.() ?? null;
		if (panel !== null) {
			// W21: the panel's cap is exact, so the force-commit loop never
			// fires on it. W22: the queue band sits below the panel — the
			// cap shrinks by it.
			const frame = panelFrameOf(panel, W, capped);
			return { lines: frame.rows, panelSpan: frame.options };
		}
		return { lines: this.#liveProjection(W, ctx, cap), panelSpan: null };
	}

	/** Phase 3 — the FORCE commits: overflow past the content cap
	 *  commits the oldest live cell (W22: the queue band shrinks the
	 *  cap by its rows) — but NEVER A TOOL CALL STILL RUNNING (DC-53).
	 *  A running card has no committed form yet: its shape changes at
	 *  the settle, so a committed one would be a row that is never
	 *  corrected — measured as a burst's first call frozen into the
	 *  scrollback with its breathing mark, its result never drawn. A
	 *  streaming text or raw cell DOES have a committed form (its rows
	 *  are final, append-only) and spills normally. When the head is
	 *  running the region gives way instead: the cards behind it
	 *  degrade, then the window shrinks (#liveProjection). */
	#capLive(lines: string[], W: number, ctx: FrameCtx, cap: number): string[] {
		while (
			lines.length > cap && // V6-3: the content cap H−4 (KC1: −N's extra rows)
			this.#committed < this.#cells.length &&
			!(this.#cells[this.#committed]!.kind === "tool" && !this.#cells[this.#committed]!.done)
		) {
			this.#commitCell(this.#committed, W, ctx);
			// TUI2-R2 ⑤: the focus re-derives after a commit — the cell it
			// pointed at may have just left the live region.
			lines = this.#liveProjection(W, ctx, cap);
		}
		return lines;
	}

	/** Phase 5 — the frame bytes: the one-time reset, autowrap off, the
	 *  synchronised-update bracket, the ONE renderer, and the
	 *  bookkeeping the next frame's relative moves start from. */
	#paint(W: number, H: number, liveTop: number, liveLines: string[], liveRowsTotal: number, chrome: Chrome): void {
		const out: string[] = [];
		// REL-0152-D14 — AUTOWRAP OFF for the frame's duration.
		//
		// Found in the owner's own capture: 97 of the rows kiso emitted at
		// 80 columns are EXACTLY 80 cells wide — the box top, the box
		// bottom, the composer row, every gap row the chrome pads out. A
		// character printed into the last column does not move the cursor
		// past it; it sets the terminal's PENDING WRAP flag, and the next
		// printed character goes to column 1 of the following row. What
		// terminals do with that flag when a cursor MOVE arrives instead
		// of a character is not agreed on — some clear it, some keep it —
		// and this frame then makes 65 relative cursor-ups through exactly
		// that state.
		//
		// So the frame's layout depended on a behaviour terminals disagree
		// about, on every frame, at every width where a row happens to
		// fill the screen. That is enough to explain a layout that is
		// correct on one terminal and damaged on another, and damaged only
		// while frames are being painted.
		//
		// With autowrap off, a character in the last column simply stays
		// there: no pending flag, no disagreement, and relative moves mean
		// what they say. kiso can never lose content to it either, because
		// #checked already refuses to emit a row wider than the screen —
		// the invariant that makes turning wrapping off safe was in place
		// long before this.
		//
		// Restored at the end of every frame: prose written OUTSIDE a
		// frame (bodyLog, an error) is ordinary output and must still
		// wrap, and the shell inherits the terminal when kiso exits.
		if (this.#needsReset) {
			// REL-0152-D19: released as the FIRST bytes of the FIRST frame
			// rather than as a write of its own. A separate write would be
			// one more thing between the dock coming up and its first
			// frame, and the PTY gates that wait on the boot stream feel
			// it; inside the frame it is four sequences and no new event.
			this.#needsReset = false;
			// REL-0161: the reset ESTABLISHES the hidden cursor (?25l) —
			// the steady state for the session's whole life. It repairs a
			// killed predecessor straight into the same state. The visible
			// cursor comes back exactly once, in editor.exit().
			// DC-40 — H line feeds BEFORE the reset, from wherever the shell
			// left the cursor. The first frame is the full-redraw path and
			// addresses rows 1..H absolutely; at launch those rows are the
			// shell's (its prompt, the launch command, the tail of whatever
			// ran before), and the frame painted over them — gone, not in
			// the scrollback (REL-0152-D20 established the mechanism; 37/60
			// shell lines survived on Apple Terminal, every line ON SCREEN
			// lost). From cursor row r, H feeds move H−r rows and then
			// scroll exactly r: the shell's rows 1..r enter the scrollback
			// as CONTENT (at most one blank row — the cursor's own line),
			// the screen is blank, and the model's assumption "row 0 is the
			// terminal's row 1" is true by construction. The count does not
			// depend on r, so nothing is asked of the terminal.
			//
			// THE ORDER IS THE FIX. `ESC[r` (DECSTBM) HOMES THE CURSOR to
			// row 1 — VT100 semantics, honoured by Apple Terminal, xterm,
			// xterm.js and tmux alike. Feeds emitted AFTER the reset start
			// from row 1, move H−1 rows and scroll ONE: measured on Apple
			// Terminal, 1/20 shell lines survived with an otherwise
			// byte-identical frame. Feeds BEFORE the reset: 20/20. The house
			// emulators did not model the homing and passed the wrong order;
			// VtScrollback does now, and the DC-40 gate is red on it.
			//
			// The reset still precedes the FRAME (REL-0152-D19: a frame
			// drawn into an inherited sub-region is the defect); only the
			// feeds run under whatever region the shell left. A region a
			// killed foreign program left set makes the feeds scroll that
			// region alone and the frame paint over the rows outside it —
			// which is what every frame did before this fix, never worse.
			out.push("\n".repeat(H));
			out.push("\x1b[r\x1b[?69l\x1b[?7h\x1b[?25l");
		}
		out.push("\x1b[?7l");
		// REL-0161: ?25l is the STEADY state now, not a frame bracket —
		// re-asserted at every frame open as self-healing (a subprocess
		// or stray output that showed the cursor is corrected here), and
		// never paired with a ?25h. Sync (2026) still brackets the frame
		// where the terminal understands it.
		out.push(this.#conservative ? "\x1b[?25l" : "\x1b[?2026h\x1b[?25l");
		// REL-0152-R1: ONE renderer. A diff emits the rows that differ, and
		// on a frame where everything differs that IS a full repaint — so
		// the old steady/full split (a scrolling path that could not draw
		// a window moving the wrong way, finding #A8) has nothing left to
		// dispatch between.
		this.#drawFull(out, W, H, liveTop, liveLines, chrome.queueRows, chrome.menuRows, chrome.editor);
		this.#fullRedraw = false;
		// REL-0161: the frame close no longer shows the cursor — hidden IS
		// the steady state (Terminal.app infers "a prompt line" from
		// bracketed-paste + a visible cursor and decorates it with a Mark;
		// the composer draws its own cursor cell instead — #inputRowBytes).
		if (!this.#conservative) out.push("\x1b[?2026l");
		out.push("\x1b[?7h"); // REL-0152-D14: autowrap back on for everything outside the frame
		this.#inFrame = true;
		try {
			this.#writeFrame(out.join("")); // the frame IS the new screen — it does not invalidate it
		} finally {
			this.#inFrame = false;
		}
		this.#lastLiveTop = liveTop;
		this.#lastLiveRows = liveRowsTotal;
		this.#lastInputRows = chrome.editor.rows.length;
		// KC1 §6: the next steady frame's relative moves start where THIS
		// frame's CHA parked the cursor — the marker's row inside the
		// composer (N = 1 ⇒ H−2, the retired hard-coded anchor).
		this.#lastAnchorRow = H - 1 - chrome.editor.rows.length + chrome.editor.markerRow;
	}

	#space(i: number, prev: readonly string[] | null, rows: string[]): string[] {
		if (i > 0 && this.#cells[i]?.kind === "md" && this.#cells[i - 1]?.kind === "md") return rows;
		// R13 D1 retires the tool cell's stand-in: the rhythm is a constant,
		// so a settle changes content and never position by construction.
		return bodySpacing(this.#lastDrawn(i, prev), rows);
	}

	/** The previous DRAWN sibling, not the previous cell: the spacing
	 *  formula reads what stood above, and a cell that rendered nothing
	 *  did not stand above anything (R3i). */
	#lastDrawn(i: number, prev: readonly string[] | null): readonly string[] | null {
		if (prev !== null && prev.length > 0) return prev;
		for (let j = i - 1; j >= 0; j -= 1) {
			const cached = this.#lineCache[j];
			if (cached !== null && cached !== undefined && cached.length > 0) return cached;
		}
		return prev;
	}

	/** Commit the cell at index i: render + cache its lines (immutable —
	 *  the force-committed form freezes at the current render), advance
	 *  the bookkeeping — and collect the lines for this frame's writes.
	 *  Pure accounting + the write list; the BYTES emit in the frame.
	 *  W11: the formula's blank above the cell (when one belongs) rides
	 *  this cell's commit — the cache stays raw, the placed rows count. */
	#commitCell(i: number, W: number, ctx: FrameCtx): void {
		const cell = this.#cells[i]!;
		const lines = cellComponent(cell).render(W, ctx);
		// W15: a tool cell whose committed rows hide something (its rows
		// carry the "ctrl+o" affordance — the renderer's OWN output, so the
		// read's "/last"-only cut note never lands here) joins the collapsed
		// index the viewer reads (ctrl+r). unshift: cells commit
		// oldest-first, so the newest cut is at the front.
		if (cell.kind === "tool" && lines.some((l) => l.includes("ctrl+o"))) this.#collapsed.unshift(i);
		this.#lineCache[i] = lines;
		const placed = this.#space(i, i > 0 ? this.#lineCache[i - 1]! : null, lines);
		this.#committed += 1;
		this.#committedLines += placed.length;
		this.#committedLinesThisFrame.push(...placed);
	}

	/* DECLARED REVERSAL (R13, owner-ruled 2026-09-03): the segment
	   bookkeeping stood here — `#stampSegment`, `#segmentOf`,
	   `#segmentHasTrouble`, `#segmentTroubleTerms`, `#markSpilled` — and
	   with it the three commit HOLDS (`#held`: W14's quiet turn, R3b/R3i's
	   segment, TUI2-R1.5 ①'s explore run). All of it decided whether a
	   fold or a rollup would stand for a done cell. Nothing folds, so a
	   done cell commits the instant it is done, and holding it back only
	   made finished work compete with the running call for rows (R7a D). */

	/* DECLARED REVERSAL (R13, owner-ruled 2026-09-03): `#foldOrRollup`
	   stood here — the commit-time decision whether a cell rendered
	   itself, a segment's fold line (R3b–R3i, W14), a W13 rollup summary
	   or TUI2-R1 (B)'s exploration row. All three collapses answered one
	   pressure (ungrounded output rows owning the screen) by turning work
	   into sentences ABOUT work; the card answers it with a constant
	   preview cap per call, and a page whose work is always the same
	   shape is one a reader can predict. Every cell renders itself. */

	/** The slot occupant's extra rows — the slash-command menu (above the
	 *  status, in the rhythm gap + the content's spare rows — the old
	 *  menu's position, slot-shaped). */
	/** W22: the pending-queue chips — the menu-rows family's other
	 *  occupant (the queue is dense, like the menu; each line is its
	 *  own chip with the □ gutter). */
	#queueRows(W: number, H: number): string[] {
		const queued = this.#queueState?.() ?? [];
		if (queued.length === 0) return [];
		// KC1 (adjudication A4): a MULTI-LINE queued message's chip shows
		// its FIRST line + a ⏎×k suffix — k = the additional lines, counted
		// after the SAME §3 normalization the editor applies (a CRLF pair
		// is ONE break), so the chip stays one row per queued turn. The
		// suffix rides INSIDE the chip as plain text: the chip renderer
		// escapes control bytes, so an SGR span would be stripped there —
		// and the cells package stays untouched this round.
		const lines = queued.map((line) => {
			const parts = line.replace(/\r\n?/g, "\n").split("\n");
			return parts.length > 1 ? `${parts[0]} ⏎×${parts.length - 1}` : line;
		});
		// A8b: the band CAPS so the content keeps its rows — an unbounded
		// band (the batch flood pastes the whole queue at once) overflowed
		// the screen: the content cap H−4−queue went negative, the march
		// painted nothing, and the leaving rows were never on the screen to
		// scroll — the scrollback lost the turns entirely (finding #A8b —
		// the queued-flood content loss). The band keeps the first H−9
		// chips + one "…N more" row (≤ H−8 rows — the content keeps ≥ 4);
		// the status hint's "+N queued" already carries the count, so the
		// cap hides nothing the status doesn't show.
		const keep = Math.max(1, H - 9);
		if (lines.length <= keep) return pendingQueueRows(lines, W);
		const p = palette();
		const hidden = lines.length - keep;
		return [...pendingQueueRows(lines.slice(0, keep), W), `${p.dim}□ …${hidden} more queued${p.reset}`];
	}

	/**
	 * The band ABOVE the box top. Two occupants share it — the slash
	 * menu and (KC3 §4) the @ file picker.
	 *
	 * Sharing is the design, not an economy. This band is already
	 * counted in chromeRows, already shrinks the live content cap,
	 * already redraws with the frame, and already clamps the composer's
	 * visible rows; a picker with a band of its own would have to
	 * re-derive every one of those and could disagree with any of them.
	 * The two occupants are mutually exclusive BY CONSTRUCTION — the
	 * editor's precedence gate keeps the picker shut whenever the menu
	 * is open — so one function can own the band without either
	 * occupant knowing the other exists.
	 */
	#menuRows(W: number): string[] {
		// TUI2-R2 ②: the session picker is the band's THIRD occupant and
		// takes it first. It is modal — it opens before a session exists,
		// so neither the menu nor the @ picker can be up beside it — and
		// riding this channel buys it the same geometry every other band
		// occupant already has: counted in chromeRows, clamped with the
		// composer, redrawn with the frame.
		const pick = this.#pickState?.() ?? null;
		if (pick !== null) return sessionPickerRows(pick, W, Date.now());
		const at = this.#atState?.() ?? null;
		if (at !== null) return atPanelRows(at, W);
		const menu = this.#menuState?.();
		if (menu === null || menu === undefined || menu.items.length === 0) return [];
		const p = palette();
		// TUI2-R1.5 ⑦(b) (VD-8): the band NAMES itself, the same way the @
		// picker's does. Both render frameless directly above the composer,
		// so with scrollback behind them there was nothing to say where the
		// surface began — the rows read as more history.
		// R8 — THE BAND IS A WINDOW, and the rows are a table.
		//
		// It used to draw every match and fold each long description over
		// as many rows as it took, which is why a bare `/` could not open
		// it: eleven commands plus wraps is most of a short terminal. A
		// fixed window is what lets the trigger be the `/` the banner
		// advertises (see the editor's #menuFiltered).
		//
		// Three shape rules, all of them §1.3 or §1.2:
		//  - the leading `/` comes off the rows. It is already on the
		//    input line directly below, so printing it eleven more times
		//    is a mark carrying no fact the screen does not have.
		//  - the name column is padded to the longest command in the
		//    WHOLE list, not the visible slice, so the descriptions do
		//    not shift sideways as the window scrolls.
		//  - a description is CUT, never folded — a folded row would
		//    break the window's height, which is the thing being bought.
		const items = menu.items;
		const col = MENU_ITEMS.reduce((n: number, m: MenuItem) => Math.max(n, m.name.length - 1), 0);
		const windowed = items.length > MENU_WINDOW;
		// the window's top is derived from the selection alone (this
		// method is re-entered per frame and keeps no state): centre it,
		// clamped to the ends.
		const top = windowed ? Math.max(0, Math.min(menu.selected - ((MENU_WINDOW - 1) >> 1), items.length - MENU_WINDOW)) : 0;
		const rows: string[] = [bandHeader("commands", W)];
		for (let i = top; i < Math.min(items.length, top + MENU_WINDOW); i += 1) {
			const item = items[i]!;
			const label = `${item.name.slice(1).padEnd(col)} ${item.desc}`;
			rows.push(...(i === menu.selected ? gutterCut(`${p.bold}▸${p.reset} `, `${p.bold}${label}${p.reset}`, W) : gutterCut("  ", `${p.dim}${label}${p.reset}`, W)));
		}
		// the counter earns its row only when the list is CUT — over a
		// list you can see all of, it says nothing the rows do not.
		if (windowed) rows.push(`  ${p.dim}(${menu.selected + 1}/${items.length})${p.reset}`);
		return rows;
	}

	/** ONE input row's bytes — the marker embedded at `embedAt` (the
	 *  cursor's display column within the row) when this row owns the
	 *  cursor, `null` on the composer's other rows. The compositor
	 *  strips the marker and returns the frame-derived CELL — the cursor
	 *  move lands AT the marker (a CHA — the column is absolute, so the
	 *  move's base is irrelevant; the retired afterW CUB's base was the
	 *  LAST write's end column, which the steady frame's gap/stale ELs
	 *  leave at col 1 — the A3 finding).
	 *
	 *  W6: the row lives INSIDE the box — the walls are a prefix/suffix
	 *  width only, composed AFTER the marker embed (the marker math is
	 *  untouched; the marker's row column = the wall + the lead + the
	 *  cursor). The content caps at W−4 (the walls' columns) and the
	 *  pad completes the row to EXACTLY W — invariant ① throws on
	 *  overflow, so the box row is built full-width, never truncated.
	 *  W23: the lead width is the ONE authority — leadWidth (width.ts),
	 *  shared with the editor's selfRender/#reflow and editCol.
	 *  KC1 §6: the walk is UNCHANGED — a one-row composer emits exactly
	 *  today's bytes (the T-C1 identity anchor). */
	#inputRowBytes(row: string, W: number, embedAt: number | null): { stripped: string; markerCell: number } {
		let markerLine = "";
		let markerCell = 0; // the marker's 0-based cell — the walk's w at the embed
		let w = 0;
		let inserted = embedAt === null; // a row without the cursor never embeds
		let i = 0;
		while (i < row.length) {
			if (row[i] === "\x1b") {
				const m = /^\x1b\[[0-9;]*m/.exec(row.slice(i));
				if (m !== null) {
					markerLine += m[0];
					i += m[0].length;
					continue;
				}
			}
			if (!inserted && w >= embedAt!) {
				markerLine += CURSOR_MARKER;
				markerCell = w;
				inserted = true;
			}
			const cw = displayWidth(row[i]!);
			// R2: no walls to pay for — but ONE column stays reserved. When
			// the cursor rests past the content the drawn cell is taken out
			// of the pad, and a walk that filled to exactly W leaves no pad
			// to take it from: the row becomes W+1 and invariant ① throws.
			// The old cap paid for two walls and a space; this pays for the
			// cursor, which is the only thing still owed a cell.
			if (w + cw > W - 1) break;
			markerLine += row[i]!;
			w += cw;
			i += 1;
		}
		if (!inserted) {
			// the walk ended before the cursor cell (the box edge) — the
			// marker rests at the row's end; the move still lands AT it
			// (the min() of the contract)
			markerLine += CURSOR_MARKER;
			markerCell = w;
		}
		if (W < 4) {
			// the degenerate screen: the box cannot hold its walls — the
			// bare row (the pre-W6 bytes; the fold probe's pass-through
			// line still crashes invariant ① downstream, as before)
			return { stripped: markerLine.replace(CURSOR_MARKER, ""), markerCell };
		}
		// REL-0161 — the DRAWN cursor. The hardware cursor is hidden for
		// the session's life (Terminal.app infers "a prompt line" from
		// bracketed-paste + a visible cursor and Marks it), so the cell
		// at the marker renders inverse instead. The hardware cursor
		// still PARKS at the marker — the IME anchor is its position.
		const mi = markerLine.indexOf(CURSOR_MARKER);
		let stripped0: string;
		let cursorPad = 0; // 1 when the drawn cursor consumed a pad cell
		if (mi < 0) {
			stripped0 = markerLine; // a row that does not own the cursor
		} else {
			const before = markerLine.slice(0, mi);
			const after = markerLine.slice(mi + CURSOR_MARKER.length);
			if (after.length === 0) {
				// the cursor rests past the content — an inverse space,
				// taken OUT of the pad (the walk capped content at W, so
				// the pad absorbs it and the row still totals W)
				stripped0 = `${before}\x1b[7m \x1b[27m`;
				cursorPad = 1;
			} else if (after[0] === "\x1b" || (after.codePointAt(0)! >= 0xd800 && after.codePointAt(0)! <= 0xdfff)) {
				// never wrap a sequence, never split a surrogate pair —
				// the cell keeps its bytes, the parked cursor still marks
				// the position for the terminal's own affordances
				stripped0 = before + after;
			} else {
				const glyph = String.fromCodePoint(after.codePointAt(0)!);
				stripped0 = `${before}\x1b[7m${glyph}\x1b[27m${after.slice(glyph.length)}`;
			}
		}
		// R2 — the box is retired (see boxTop): the composer is two dashed
		// rules and the row between them, so there are no walls to pay for
		// and no pad to hold them off. The row is exactly W, as it always
		// was; what changed is that all W columns belong to the input.
		const padW = Math.max(0, W - w - cursorPad);
		return { stripped: `${stripped0}${" ".repeat(padW)}`, markerCell };
	}

	/** KC1 §6 — the focus component's input ROWS (N = 1 today's single
	 *  row, byte for byte). The lead rides the FIRST row and the
	 *  continuations indent by its width, so the cursor's column formula
	 *  is the same on every row; the CURSOR'S row carries the marker and
	 *  the frame derives the cursor from it — row AND column — with no
	 *  editPos side channel.
	 *
	 *  The rows arrive already windowed by the editor's §5 estimate; the
	 *  frame re-applies the SAME clamp against the REAL folded menu and
	 *  queue bands (N_visible's height term), keeping the cursor's row
	 *  in view — so the geometry is legal at every terminal size. */
	#inputRows(W: number, H: number, menuRows: number, queueRows: number): { rows: string[]; markerRow: number; markerCol: number } {
		const st = this.#inputState();
		const panel = this.#panelState?.() ?? null;
		// the lead — the panel's phase lead when the panel owns the row
		// (1-3> / the rule input's "2 Yes, don't ask again for " / the
		// amend "feedback (deny): "), the bound prompt otherwise
		const lead = panel !== null ? panelLeadOf(panel) : this.#inputPrompt;
		const leadW = leadWidth(lead);
		// a LEGACY one-row provider (the old {line, cursor} shape) keeps
		// working: its single line is the composer's single row
		let rows = st.lines !== undefined && st.lines.length > 0 ? [...st.lines] : [st.line];
		let cursorRow = Math.min(st.cursorRow ?? 0, rows.length - 1);
		const cursorCol = st.cursorCol ?? st.cursor;
		// KC1 §5's N_visible, re-applied against the frame's REAL bands:
		// the editor could only estimate the menu/queue heights (they
		// fold at width), so the frame is the authority. The window keeps
		// the CURSOR'S row, so a clamp never hides it.
		const n = Math.max(1, Math.min(rows.length, H - 3 - menuRows - queueRows));
		if (rows.length > n) {
			const first = Math.max(0, Math.min(cursorRow - n + 1, rows.length - n));
			rows = rows.slice(first, first + n);
			cursorRow -= first;
		}
		const out: string[] = [];
		let markerCol = 1; // R2: no wall to skip — the row starts at column 1
		for (let r = 0; r < rows.length; r += 1) {
			const text = `${r === 0 ? lead : " ".repeat(leadW)}${rows[r]!}`;
			const bytes = this.#inputRowBytes(text, W, r === cursorRow ? leadW + cursorCol : null);
			out.push(bytes.stripped);
			// W23: the frame-derived column — wallL (2) + the marker's
			// cell + 1 — the CHA lands the cursor AT the marker from ANY base
			if (r === cursorRow) markerCol = 1 + bytes.markerCell;
		}
		return { rows: out, markerRow: cursorRow, markerCol };
	}

	/** The full-redraw path (the first frame, the resize repaint) — CUP
	 *  allowed here; zero LF; zero \x1b[3J; zero replay. The committed
	 *  lines (this frame's) write at [liveTop−N .. liveTop−1].
	 *
	 *  V6-1 (the screen-state == frame-state rule): every row 1..H is
	 *  covered — the committed/live/chrome writes AND the EL-only rows
	 *  (above the committed section, the gap). The terminal's reflow
	 *  re-wraps the old content at the new size — its shifted copies
	 *  survive anywhere the draw does not touch; a draw that covers
	 *  EVERY row is idempotent: N consecutive resizes end with the same
	 *  screen as a single jump to the same size. */
	#drawFull(out: string[], W: number, H: number, liveTop: number, liveLines: string[], queueRows: string[], menuRows: string[], editor: { rows: string[]; markerRow: number; markerCol: number }): void {
		const overlay = this.#overlayFrame;
		const inputExtra = editor.rows.length - 1; // KC1: the composer's rows above the retired single input row
		const committed = this.#committedLinesThisFrame;
		// 0. the FROZEN rows — the re-folded committed content (re-flowed
		//    at the new width by the terminal): re-painted at [1..frozen],
		//    so the reflow's shifted copies can never ghost. W11: the
		//    formula's blanks between the cells are re-inserted here — the
		//    cache holds each cell's OWN rows; a missing blank would paint
		//    every row below it one row too high (the V6-1 idempotence
		//    rule: this draw must reproduce the screen, row by row).
		//    The bound is the CELL count at the frame's start — the force
		//    commit's placed LINES can exceed the cell count, and the old
		//    lines-bound went negative, skipping every previously-committed
		//    cell (the V6-1 frozen-loop finding — the banner vanished).
		const frozen: string[] = [];
		for (let i = 0; i < this.#committedAtFrameStart; i += 1) {
			frozen.push(...this.#space(i, i > 0 ? this.#lineCache[i - 1]! : null, this.#lineCache[i]!));
		}
		// A8: the march is the WINDOW — the model's last H rows. When the
		// model total (committed + live + chrome) exceeds H, the window's
		// first row is the model's (total − H + 1)-th line: the lines
		// above the window belong in the scrollback, and painting them at
		// rows 1.. would shift every row below by the same (total − H) —
		// the live region lands past its model position and the box eats
		// its tail. The bound skips them: the march covers exactly the
		// window (the committed share + the live + the chrome), r
		// monotone, every row 1..H re-painted (the V6-1 every-row rule).
		const all = [...frozen, ...committed, ...liveLines];
		// TUI2-R1.5 7(a) (VD-8): while the sheet is up the window does NOT
		// move. skip is frozen at its pre-open value and #lastSkip is left
		// alone, so no LF is emitted and nothing enters the scrollback; the
		// march below is clamped to the window instead, which makes the
		// sheet displace content ON SCREEN. Closing takes the full-redraw
		// path with the same #lastSkip and every displaced row comes back.
		// R7a — a monotone skip was TRIED HERE AND REJECTED, measured.
		//
		// The seam it aimed at is real: the turn boundary releases the
		// block into a one-row fold, so a full screen's computed skip
		// drops and every row above slides down one. Holding skip at its
		// high-water mark removes that motion exactly.
		//
		// It also holds the window BELOW the content, and the a7 dogfood
		// replay prices that at 40x24: the frame from which the screen
		// durably fills (no blank run over 2) goes 65 -> 692 of 733 —
		// a three-row hole above the composer through most of a real
		// session. One row of motion once per turn, at the moment the
		// answer lands and the eye is on it, is the cheaper of the two.
		// The A8b guard is written against a real session; this is what
		// it exists to catch.
		const fresh = Math.max(0, all.length + CHROME_ROWS + inputExtra + queueRows.length + menuRows.length - H);
		// R13 — THE WINDOW'S TOP NEVER FALLS. `fresh` is read off the
		// CURRENT model height, so it drops the moment the live region
		// shrinks — and rows [0, #scrolledOff) are already in the
		// terminal's scrollback, immutable (ADR-0046). Painting them again
		// is a window that un-scrolls, which a terminal cannot do: the
		// rows come back on screen while their originals stay in the
		// history above, and the transcript gains a duplicate.
		//
		// R4's standing slot made the live region monotone WITHIN a turn,
		// so this could not arise and the clamp was never needed. R13
		// retires the slot — a card shrinks when its call settles (E2) —
		// which is what put the fall on the table. The clamp is the same
		// rule `#emitScroll`'s floor already keeps for the scroll; it now
		// also governs the paint.
		//
		// A RESIZE is exempt, and must be: the terminal reflows and
		// scrolls on its own before we are called, so the fresh count is
		// the truth there and a high-water mark is DC-34's own defect.
		const skip = overlay ? this.#lastSkip : this.#resizeFrame ? fresh : Math.max(this.#scrolledOff, fresh);
		// A8b (the shrink-trigger's completion): the rows that LEAVE the
		// window scroll into the terminal's scrollback — the LF mechanism
		// (the steady path's own). Only the rows the paint re-covers (the
		// overlap with the new window) are EL'd first — the A7 single-copy
		// discipline; the purely-leaving rows scroll WITH their content
		// (they are never re-painted — the scrollback is their record).
		// Without the scroll the shrink frames overwrite the leaving rows
		// in place — a batch-fed session (the queue drains every turn — a
		// shrink EVERY frame) loses the scrolled-away turns from the
		// terminal's scrollback entirely (finding #A8b — the queued-flood
		// content loss).
		// REL-0152-R1: the scroll is the frame's only irreversible act and
		// lives in one place now. The FLOOR is where the window's top would
		// sit with the live band empty and the chrome at its minimum — the
		// one-way part of a movement that otherwise goes both ways.
		if (this.#resizeFrame) {
			// R14 / route B — THE RESIZE FRAME SCROLLS LIKE ANY OTHER.
			//
			// Everything this branch used to hold is retired with the
			// window arithmetic it served. It adopted the terminal's own
			// reflow-scroll into `#scrolledOff` (REL-0152-R1), then had to
			// stop adopting it on a widen and keep adopting it on a narrow
			// (DC-34), because the counter it was feeding meant a different
			// thing at every fold width. There is no such counter to feed
			// now: `#settleResize` erased the terminal and set
			// `#scrolledOff` to zero, so the frontier is real and empty and
			// the frame simply reprints from the top.
			//
			// Falling through to `#emitScroll` is not a convenience — it is
			// the whole point. The transcript above the last screenful has
			// to reach the scrollback, chunked and staged from the model,
			// exactly as a resumed session's replay does. Without it the
			// reprint painted the last screenful onto a terminal whose
			// history it had just erased, and everything above was simply
			// GONE: `dc34-widen-seam` measured 36 tokens missing from the
			// scrollback the first time this branch was left in place.
			this.#screen = new Array(H).fill(NOT_PAINTED);
			this.#resizeFrame = false;
		}
		if (!overlay) {

			// DC-46 — THE ROWS THAT LEAVE THE WINDOW SCROLL, and the target
			// is `skip` itself.
			//
			// It used to be a FLOOR: where the window's top would sit with
			// the live band empty. The floor was the conservative choice
			// because the top could come back down when the live region
			// shrank, and a scroll is the frame's one irreversible act — so
			// only the part of the movement that could never reverse was
			// paid out.
			//
			// R13 makes the top monotone (the clamp above: rows in
			// [0, #scrolledOff) are in the terminal's scrollback and the
			// paint may not go back above them), so a row above `skip` has
			// left for good and there is nothing conservative left to be.
			// Keeping the floor with a live region that can now grow by a
			// whole card LOST rows: painted over in place, never scrolled,
			// present in neither the screen nor the scrollback. Measured on
			// R7a D — a four-call burst on a 24-row terminal, and the first
			// call's head row was never emitted at all.
			this.#emitScroll(out, W, H, all, skip);
		}
		if (!overlay) this.#lastSkip = skip;
		// REL-0152-R1: the rows this frame WANTS on the screen — the same
		// placement the full redraw has always computed, lifted out of the
		// emission so it can be compared against what is there.
		const desired: string[] = new Array(H).fill("");
		let r = 1;
		// the window's content rows: everything above the chrome. With the
		// overlay up `all` can exceed it, and the rows that give way are the
		// OLDEST on screen — they are still in the model and come back on
		// the close.
		const contentRows = Math.max(0, H - CHROME_ROWS - inputExtra - queueRows.length - menuRows.length);
		// The march starts at `skip`, which is already clamped to the
		// frontier above (rows in [0, #scrolledOff) are the terminal's and
		// are never painted again). DC-34's width-only reach-back guard
		// stood here until R14: a resize now reprints from the model, so
		// there is no stale fold for a width change to re-index.
		const march = all.slice(skip);
		for (const line of march.length > contentRows ? march.slice(march.length - contentRows) : march) {
			desired[r - 1] = this.#checked(line, W);
			r += 1;
		}
		// 3. the GAP rows (between the live content and the chrome) — blank.
		for (let rr = r; rr <= H - 4 - inputExtra; rr += 1) desired[rr - 1] = "";
		// W22: the queue chips sit directly above the box top (the
		// "pre-render ABOVE the input row"), the menu above the queue.
		const queueTop = H - 3 - inputExtra - queueRows.length;
		const menuTop = queueTop - menuRows.length;
		for (let i = 0; i < queueRows.length; i += 1) desired[queueTop + i - 1] = this.#checked(queueRows[i]!, W);
		for (let i = 0; i < menuRows.length; i += 1) desired[menuTop + i - 1] = this.#checked(menuRows[i]!, W);
		// V6-3 + W6 + KC1 §6: the design §03 chrome — box top (H−2−N),
		// the composer's N input rows (H−1−N .. H−2), box bottom (H−1),
		// status (H). N = 1 is the retired four-row chrome exactly.
		desired[H - 3 - inputExtra - 1] = boxTop(W);
		for (let i = 0; i < editor.rows.length; i += 1) desired[H - 2 - inputExtra + i - 1] = this.#checked(editor.rows[i]!, W);
		desired[H - 1 - 1] = boxBottom(W);
		const statusRow = this.#statusSource();
		desired[H - 1] = this.#checked(statusLine(statusRow.status, this.#tail, W, statusRow.hint, statusRow.expand), W);
		this.#emitDiff(out, W, H, desired);
		// REL-0152-R1: park from where the cursor ACTUALLY is — see
		// #cursorRow. It used to be parked from H, which the bottom-up
		// march guaranteed and a diff does not.
		this.#parkCursor(out, this.#cursorRow, H - 2 - inputExtra + editor.markerRow, editor.markerCol);
		this.#cursorRow = H - 2 - inputExtra + editor.markerRow;
	}

	/**
	 * REL-0152-R1 — emit the difference between the screen that is up and
	 * the screen this frame wants, and adopt the new one.
	 *
	 * One CUP + erase + content per CHANGED row and nothing for the rest.
	 * A streaming delta moves the live band and leaves the status row,
	 * the box, the composer and the queue exactly as they were — 13 rows
	 * were being erased per keystroke for a change that touches one, and
	 * those twelve are the tear's whole surface (REL-0152-D1).
	 *
	 * Correctness does not depend on the diff being clever. It depends on
	 * #screen being what the terminal shows, which is why every path that
	 * moves rows updates it: a wrong row is repaired by the next frame,
	 * because the difference includes it.
	 */
	#emitDiff(out: string[], W: number, H: number, desired: readonly string[]): void {
		if (this.#screen.length !== H) this.#screen = new Array(H).fill(NOT_PAINTED);
		for (let i = 0; i < H; i += 1) {
			const want = desired[i] ?? "";
			if (this.#screen[i] === want) continue;
			out.push(want === "" ? `\x1b[${i + 1};1H\x1b[0K` : `\x1b[${i + 1};1H\x1b[0K${want}`);
			this.#cursorRow = i + 1; // a CUP write leaves the cursor on that row
		}
		this.#screen = [...desired];
	}

	/**
	 * REL-0152-R1 — the scroll, and the only irreversible thing a frame
	 * does.
	 *
	 * `leaving` rows go into the terminal's scrollback, which cannot be
	 * rewritten, so two things have to be right BEFORE the LFs: the count,
	 * and what is standing in rows 1..leaving.
	 *
	 * The count is bounded by the FLOOR — where the window's top would sit
	 * with the live band empty and the chrome at its minimum. That is the
	 * one-way part of the window's movement; the rest of it follows a band
	 * whose height goes up and down, and scrolling on that pushed rows
	 * away that the next shrink brought back (the A7 replay's frame 106).
	 *
	 * What is standing there is STAGED from the model rather than assumed.
	 * The old renderer assumed the leaving rows were already correct on
	 * screen and was right until a growing live band painted over one of
	 * them; then the LFs carried the live band's leftover into the
	 * scrollback and the committed row it had displaced was in no
	 * scrollback and on no screen. That is the owner's swallowed message
	 * (REL-0152-D7), and staging is what makes it structurally impossible.
	 */
	#emitScroll(out: string[], W: number, H: number, all: readonly string[], floor: number): number {
		const target = Math.max(0, Math.min(floor, all.length));
		const leaving = Math.max(0, target - this.#scrolledOff);
		if (leaving === 0) return 0;
		if (this.#screen.length !== H) this.#screen = new Array(H).fill(NOT_PAINTED);
		// a transit taller than the screen cannot be staged in one pass —
		// rows placed past H are clamped by the terminal itself and the
		// pile keeps only its last member (finding TUI2-MD-1). Chunked, at
		// most H rows at a time, every row on screen when its slot comes up.
		let p = this.#scrolledOff;
		while (p < target) {
			const chunk = Math.min(target - p, H);
			for (let k = 0; k < chunk; k += 1) {
				const row = all[p + k];
				out.push(row === undefined || row === "" ? `\x1b[${k + 1};1H\x1b[0K` : `\x1b[${k + 1};1H\x1b[0K${this.#checked(row, W)}`);
			}
			if (chunk < H) out.push(`\x1b[${chunk + 1};1H\x1b[0J`);
			out.push(`\x1b[${H};1H`);
			for (let k = 0; k < chunk; k += 1) out.push("\n");
			this.#cursorRow = H; // the LFs at the last row leave it there
			p += chunk;
		}
		this.#scrolledOff = target;
		// The screen after a scroll is not worth modelling row by row: the
		// staging painted rows 1..chunk, the ED blanked everything below
		// them, and the LFs then shifted all of it up — per chunk. An
		// earlier version modelled only the shift, forgot the ED, and the
		// diff below then skipped rows the terminal had already blanked:
		// a 19-row blank band on a 24-row screen, which is most of it.
		//
		// So a scrolled frame forgets the screen and repaints. That costs
		// nothing worth having: a scroll happens only when the COMMITTED
		// height crosses the floor, and a commit frame changes most rows
		// anyway. The frames the diff exists for — a streaming delta, a
		// keystroke — commit nothing, scroll nothing, and repaint only
		// what moved.
		this.#screen = new Array(H).fill(NOT_PAINTED);
		return leaving;
	}


	/**
	 * TUI2-R2 ⑤ (the R1.5 parked ⑩) — CURSOR AUTHORITY: the ONE frame-tail
	 * positioning sequence, and the compositor's alone.
	 *
	 * Both draw paths ended with their own hand-rolled park — the full
	 * path counting rows up from the status line, the steady path counting
	 * down from a six-branch re-derivation of which write happened to be
	 * last. Two implementations of one contract, each re-deriving byte
	 * order the drawing code already knew, and the walkthrough found the
	 * consequence three times over (the cursor resting in the status
	 * line's "de▮ault", at the end of streamed text, inside an approval
	 * panel's rule row). A terminal cursor is the product's claim about
	 * where the next keystroke lands; a claim made in two places is a
	 * claim that will eventually disagree with itself.
	 *
	 * One owner, one sequence: a single vertical move to the marker's row
	 * — in EITHER direction, which the steady path could not do (its move
	 * was `if (down > 0)`, so a cursor left BELOW the composer simply
	 * stayed there) — then the CHA to the frame-derived column.
	 *
	 * Relative, not a CUP, and deliberately: invariant ② reserves absolute
	 * addressing for the content area, and the composer is chrome. The
	 * CHA is absolute in the COLUMN only, which is what makes the park
	 * independent of wherever the last write ended (the A3 finding: the
	 * retired CUB's base was the gap EL's column 1, left of the lead).
	 */
	/**
	 * REL-0152-R1 — park ABSOLUTELY.
	 *
	 * This was a relative move, and it could be: the old bottom-up march
	 * always ended on the status row, so the base was H by construction.
	 * A diff ends on whatever row changed last, and on a streaming frame
	 * that is the live band. Tracking the base is possible but it makes
	 * the cursor's correctness depend on every writer in this file
	 * remembering to update a counter — and the PTY gates that assert
	 * "every frame ends with the cursor on an input row" caught exactly
	 * that going wrong.
	 *
	 * A CUP to the row needs no base at all. The CHA for the column
	 * stays: it was already absolute (the A3 finding retired the CUB
	 * whose base was the last write's end column), and the frame-derived
	 * column contract is asserted on it.
	 */
	#parkCursor(out: string[], _fromRow: number, toRow: number, col: number): void {
		out.push(`\x1b[${toRow};1H`);
		out.push(`\x1b[${col}G`);
	}

	/** Invariant ①: every emitted line fits the width — a violation is a
	 *  CRASH with the diagnostic, never a silent truncate. */
	/** DC-48 — the field cut is announced ONCE per session. */
	#cutOnce = false;
	/** HF-1: the ①b notice, once per session (the same discipline as #cutOnce). */
	#breakOnce = false;

	#checked(line: string, W: number): string {
		// Invariant ①b (R3f): a ROW IS ONE PHYSICAL ROW.
		//
		// The defect this catches shipped in 0.16.6 and smashed the
		// composer. `escapeTerminal` keeps `\n` (it strips C0 except tab
		// and newline), and `charWidth(0x0A)` is 1 — so a newline counts as
		// ONE CELL in `visibleWidth`, and every width check in the product,
		// invariant ① included, waves a multi-line string through as a
		// single row of legal width. `#emitDiff` then paints it as
		// `CUP(row,1) + EL + content`, the terminal's ONLCR moves the
		// cursor down at the newline, and the tail lands on whatever
		// physical row is there — the box rail, the input row. The diff
		// then adopts `desired` as the screen's truth, so the corruption
		// SURVIVES: the self-healing property this renderer is built on
		// ("a wrong row is repaired by the next frame, because the
		// difference includes it") is exactly what a lying `#screen`
		// breaks.
		//
		// Width was never the whole invariant — it was the half we
		// noticed. A row that occupies two physical rows violates the
		// geometry as surely as one that overruns the width, and it does
		// so INVISIBLY to a width check. `\r` is here for the same reason
		// (it moves the cursor to column 1).
		const bad = /[\n\r]/.exec(line);
		if (bad !== null) {
			// HF-1 (0.32.1): the SAME ruling as the width half below. This
			// threw in the field on a heredoc shell command (the running
			// card's head carried the model's newlines) and the owner's
			// session died with it. Under test the crash keeps its teeth;
			// in the field the break is projected to ⏎ — the row goes out
			// as one row — and a notice says so once. The builders project
			// first (tui-cells `oneRow`), so this branch is the net under
			// the net: a builder nobody has found yet costs a mark, not a
			// session.
			const why = `kiso-tui invariant ①b violated: a row containing ${JSON.stringify(bad[0])} was about to be emitted — a row must be ONE physical row, and the width check cannot see this (charWidth counts a newline as one cell) — ${JSON.stringify(line.slice(0, 80))}`;
			if (process.env.KISO_INVARIANTS === "throw") throw new Error(why);
			if (!this.#breakOnce) {
				this.#breakOnce = true;
				queueMicrotask(() => this.notice("kiso-tui: a row carried a line break and was shown as one row (invariant ①b) · please report"));
			}
			line = oneRow(line);
		}
		const w = visibleWidth(line);
		if (w > W) {
			// DECLARED REVERSAL of "the crash is the contract, not a
			// symptom" — owner-lane ruling 2026-09-04, after the SECOND
			// instance of this class in two days: DC-45 in a gate, DC-48 in
			// the owner's hands. Under test the crash is exactly right and
			// keeps every tooth; in the field it costs a human the
			// composer's contents and the whole session, to save them a row
			// that is one column too wide.
			//
			// So: THROW UNDER TEST, CUT IN THE FIELD, and say so. The
			// notice is once per session — a defect worth reporting is
			// worth saying once, and a row-by-row complaint on a resize
			// storm would be its own defect.
			const why = `kiso-tui invariant ① violated: a line of visible width ${w} > ${W} was about to be emitted — ${JSON.stringify(line.slice(0, 80))}`;
			if (process.env.KISO_INVARIANTS === "throw") throw new Error(why);
			if (!this.#cutOnce) {
				this.#cutOnce = true;
				queueMicrotask(() => this.notice("kiso-tui: a row was cut to width (invariant ①) · please report"));
			}
			return cutLine(line, W);
		}
		return line;
	}

	#toolCell(callId: string): BodyCell | null {
		const i = this.#toolCells.get(callId);
		return i === undefined ? null : (this.#cells[i] ?? null);
	}

	/** Close an open TEXT cell when a new cell starts (see v2d — the
	 *  runtime emits no text_end; the next cell is the close signal).
	 *  TUI2-MD ⑤: that same signal ends the markdown message — the open
	 *  tail block closes and its cell becomes commit-eligible. */
	#closeOpenText(): void {
		this.#endMd();
	}

	/** Close an open thinking cell when a new cell starts. */
	#closeOpenThinking(): void {
		if (!this.#isActive() && this.#pipeBuf !== "") {
			this.#lastThinking = this.#pipeBuf;
			this.#write(foldThinking(this.#pipeBuf));
			this.#pipeBuf = "";
			return;
		}
		const last = this.#cells[this.#cells.length - 1];
		if (last !== undefined && last.kind === "thinking" && !last.done) {
			last.done = true;
			this.#lastThinking = last.text;
		}
	}
}

/** The Dock — the CLI's module-scope singleton façade. Every method
 *  delegates to the one compositor (registered at construction); the
 *  input/menu bindings, which the CLI performs BEFORE the Body exists,
 *  are buffered and applied by the Body's constructor. */
export class Dock {
	get active(): boolean {
		return compositorRef !== null && compositorRef.active;
	}
	enter(): void {
		compositorRef?.enter();
	}
	exit(): void {
		compositorRef?.exit();
	}
	onResize(): void {
		compositorRef?.onResize();
	}
	/** DC-3 — the terminal answered what its background is; repaint. */
	onGroundChange(): void {
		compositorRef?.onGroundChange();
	}
	/** TUI2-R3v2 ②: where the last frame put the panel's clickable option
	 *  rows (absolute screen rows). The editor binds this and does no row
	 *  arithmetic of its own. */
	panelOptionRows(): { top: number; count: number; first: number } | null {
		return compositorRef?.panelOptionRows() ?? null;
	}
	setStatus(text: string, hint?: string | null): void {
		compositorRef?.setStatus(text, hint ?? null);
	}
	setTail(tail: string): void {
		compositorRef?.setTail(tail);
	}
	/** W21: bind the editor's panel state — the PanelSelect slot
	 *  occupant (the panel replaces the live region + the input lead
	 *  while up; the old ApprovalPrompt's question slot retires). */
	bindApproval(state: () => PanelState | null): void {
		if (compositorRef === null) {
			dockBindings.panel = state; // the live buffer — order-agnostic
			return;
		}
		compositorRef.bindApproval(state);
	}
	/** TUI2-R1 (D): bind the editor's keys-sheet flag — the slot read for
	 *  the ? overlay (the menu/picker binding pattern). */
	bindSheet(state: () => boolean): void {
		if (compositorRef === null) {
			dockBindings.sheet = state;
			return;
		}
		compositorRef.bindSheet(state);
	}
	/** R5 — the transcript viewer's three doors, forwarded to the live
	 *  compositor. Unlike the other bindings there is no buffer: the
	 *  viewer cannot be open before a compositor exists, so a call with
	 *  no compositor is a no-op rather than a queued intent. */
	viewerOpen(): boolean {
		return compositorRef !== null && compositorRef.viewerOpen();
	}
	viewerToggleMode(): void {
		compositorRef?.viewerToggleMode();
	}
	viewerKey(cmd: "up" | "down" | "toggle" | "all" | "pageUp" | "pageDown" | "home" | "end"): void {
		compositorRef?.viewerKey(cmd);
	}
	bindInput(state: () => InputState, prompt: string): void {
		if (compositorRef === null) {
			dockBindings.state = state; // the live buffer — order-agnostic
			dockBindings.prompt = prompt;
			return;
		}
		compositorRef.bindInput(state, prompt);
	}
	bindMenu(state: () => { items: readonly MenuItem[]; selected: number } | null): void {
		if (compositorRef === null) {
			dockBindings.menu = state;
			return;
		}
		compositorRef.bindMenu(state);
	}
	/** KC3 §4: bind the editor's @ picker — the SAME band as the slash
	 *  menu (see Body#menuRows). Unbound, the picker cannot render, and
	 *  every frame is byte-identical to before the round. */
	bindAt(state: () => AtPanelState | null): void {
		if (compositorRef === null) {
			dockBindings.at = state;
			return;
		}
		compositorRef.bindAt(state);
	}
	/** TUI2-R2 ②: bind the editor's session picker — the band's third
	 *  occupant. Unbound (every path but bare `kiso resume`), the picker
	 *  cannot render and every frame is byte-identical to before. */
	bindPick(state: () => SessionPickState | null): void {
		if (compositorRef === null) {
			dockBindings.pick = state;
			return;
		}
		compositorRef.bindPick(state);
	}
	/** W22: bind the pending-turn queue — the chips + the +N queued
	 *  hint (the CLI binds it from chat(); the editor's pop keys ride
	 *  the LineInput's own bindQueue). */
	bindQueue(state: () => readonly string[]): void {
		if (compositorRef === null) {
			dockBindings.queue = state;
			return;
		}
		compositorRef.bindQueue(state);
	}
	editCol(): number {
		return compositorRef?.editCol() ?? 1;
	}
	redraw(): void {
		compositorRef?.redraw();
	}
}

/** The one-compositor registry — the Dock façade routes to it. */
let compositorRef: Body | null = null;

/** The Dock's pre-compositor bindings — a LIVE object the bind methods
 *  mutate (the CLI binds the editor state before the Body exists; the
 *  Body's constructor applies it). W21: order-agnostic by construction
 *  — the old snapshot froze `menu` at bindInput time and the slash-
 *  command menu silently never bound in the real CLI (the e2e gates
 *  bind the Body directly and could not see it). */
const dockBindings: {
	state: (() => InputState) | null;
	prompt: string;
	menu: (() => { items: readonly MenuItem[]; selected: number } | null) | null;
	at: (() => AtPanelState | null) | null;
	pick: (() => SessionPickState | null) | null;
	panel: (() => PanelState | null) | null;
	sheet: (() => boolean) | null;
	queue: (() => readonly string[]) | null;
} = { state: null, prompt: "", menu: null, at: null, pick: null, panel: null, sheet: null, queue: null };
