# The three longest top-level exported function bodies

Ranked by `end - start` — the number of lines the body spans (the `export function` line through the column-0 `}` that closes it), taken from the entries in `answers.json`.

| # | File | Function | Length (end − start) | Line span |
|---|------|----------|----------------------|-----------|
| 1 | `src/cells/approval-panel.ts` | `panelBlockLayout` | 136 | 619–755 |
| 2 | `src/tui/lines.ts` | `renderEvent` | 93 | 84–177 |
| 3 | `src/cells/approval-panel.ts` | `pickBlockRows` | 88 | 858–946 |

Notes:

- `panelBlockLayout` renders the approval panel block's rows and reports where its option rows landed, so the click hit-test and the picture share one piece of arithmetic.
- `renderEvent` renders one event of the tui's own render input into the text, newline and prompt flags the line-mode path prints.
- `pickBlockRows` renders the pick panel's block rows — header, numbered options, optional level strip, type row and affordance — within the row budget.

The next three, for reference: `bannerLines` (`src/cells/render.ts`, 612–696, 84), `askBlockRows` (`src/tui/ask-panel.ts`, 310–381, 71), `askKey` (`src/tui/ask-panel.ts`, 158–222, 64).
