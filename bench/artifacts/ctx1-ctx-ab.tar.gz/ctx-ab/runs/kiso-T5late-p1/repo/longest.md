# The three longest function bodies

Length is `end - start` from the entries in `answers.json`: the number of lines from the
`export function` line to the line of the `}` that closes the body, minus one — so the
length counts the lines strictly between the declaration and its closing brace.

| # | file | function | length | span |
|---|---|---|---|---|
| 1 | `cells/approval-panel.ts` | `panelBlockLayout` | 136 | 619-755 |
| 2 | `tui/lines.ts` | `renderEvent` | 93 | 84-177 |
| 3 | `cells/approval-panel.ts` | `pickBlockRows` | 88 | 858-946 |

Next in line, for reference: `cells/render.ts` `bannerLines` (612-696, 84),
`tui/ask-panel.ts` `askBlockRows` (310-381, 71), `tui/ask-panel.ts` `askKey` (158-222, 64).

- **`panelBlockLayout`** (136) — lays out the whole approval panel block: the opening rule,
  the why-asked line, the title, the args folded and capped with a cut notice, the risk
  hint, the option window around the cursor, the affordance and the closing rule.
- **`renderEvent`** (93) — the event switch: one `RenderInput` event in, the printed text
  plus its newline/prompt flags out, including the full approval detail.
- **`pickBlockRows`** (88) — the pick panel's rows: header, numbered options with a note
  column and level strip, the `+N more` row, the type-it row and the affordance.
