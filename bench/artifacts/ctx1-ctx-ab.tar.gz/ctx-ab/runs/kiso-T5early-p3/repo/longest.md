# The three longest function bodies

Length is `end - start` from the entries in `answers.json` (the `export function` line to the column-0 `}` that closes the body).

| # | File | Function | Lines (start–end) | Length |
|---|------|----------|-------------------|--------|
| 1 | `src/cells/approval-panel.ts` | `panelBlockLayout` | 619–755 | 136 |
| 2 | `src/tui/lines.ts` | `renderEvent` | 84–177 | 93 |
| 3 | `src/cells/approval-panel.ts` | `pickBlockRows` | 858–946 | 88 |

Runners-up, for scale: `bannerLines` (`src/cells/render.ts`, 612–696) at 84, `askBlockRows` (`src/tui/ask-panel.ts`, 310–381) at 71, `askKey` (same file, 158–222) at 64.
