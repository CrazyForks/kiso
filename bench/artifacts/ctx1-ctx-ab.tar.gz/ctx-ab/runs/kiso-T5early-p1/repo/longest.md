# Longest exported function bodies

Three longest top-level exported functions in `src/`, by body length (`end − start`, where `start` is the `export function` line and `end` the line of its closing `}`). Derived from the entries in `answers.json`.

| # | file | function | length | lines |
|---|---|---|---|---|
| 1 | `cells/approval-panel.ts` | `panelBlockLayout` | 136 | 619–755 |
| 2 | `tui/lines.ts` | `renderEvent` | 93 | 84–177 |
| 3 | `cells/approval-panel.ts` | `pickBlockRows` | 88 | 858–946 |

Runners-up: `cells/render.ts` `bannerLines` (84), `tui/ask-panel.ts` `askBlockRows` (71), `tui/ask-panel.ts` `askKey` (64).
