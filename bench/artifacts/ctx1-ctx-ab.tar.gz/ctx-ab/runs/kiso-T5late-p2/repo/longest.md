# The three longest function bodies

Measured from `answers.json` as `end − start` (the closing `}` line minus the `export function` line).

| # | file | function | start–end | length |
|---|------|----------|-----------|--------|
| 1 | `src/cells/approval-panel.ts` | `panelBlockLayout` | 619–755 | 136 |
| 2 | `src/tui/lines.ts` | `renderEvent` | 84–177 | 93 |
| 3 | `src/cells/approval-panel.ts` | `pickBlockRows` | 858–946 | 88 |

Runner-up, for scale: `src/cells/render.ts` `bannerLines` (612–696, 84).
