# The three longest function bodies

Body length = `end − start` from `answers.json`, i.e. the number of lines from the
`export function` line through the `}` that closes the body (both counted, 1-based).
Paths are relative to `src/`.

| # | file | function | length | lines |
|---|------|----------|-------:|-------|
| 1 | `cells/approval-panel.ts` | `panelBlockLayout` | 136 | 619–755 |
| 2 | `tui/lines.ts` | `renderEvent` | 93 | 84–177 |
| 3 | `cells/approval-panel.ts` | `pickBlockRows` | 88 | 858–946 |

Runners-up, for scale: `cells/render.ts` `bannerLines` 84 (612–696),
`tui/ask-panel.ts` `askBlockRows` 71 (310–381), `tui/ask-panel.ts` `askKey` 64 (158–222).
