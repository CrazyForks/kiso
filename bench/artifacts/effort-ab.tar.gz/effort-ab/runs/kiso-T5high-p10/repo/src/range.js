// Parse "a-b" into a numeric range and clamp values into it.
export function parseRange(str) {
	const [a, b] = str.split("-").map(Number);
	return a <= b ? { start: a, end: b } : { start: b, end: a };
}

export function clamp(n, min, max) {
	if (n < min) return min;
	if (n > max) return max;
	return n;
}

export function isBetween(n, lo, hi) {
	return n >= lo && n <= hi;
}

export function maxOf(values) {
	if (values.length === 0) return null;
	return Math.max(...values);
}

export function formatRange(a, b) {
	return a <= b ? `${a}-${b}` : `${b}-${a}`;
}

// Parts that don't yield a finite range are skipped rather than throwing.
export function parseRangeList(text) {
	const ranges = [];
	for (const part of String(text).split(",")) {
		const { start, end } = parseRange(part);
		if (Number.isFinite(start) && Number.isFinite(end)) {
			ranges.push({ start, end });
		}
	}
	return ranges;
}
