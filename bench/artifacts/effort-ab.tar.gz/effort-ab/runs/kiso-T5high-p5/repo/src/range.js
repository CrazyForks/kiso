// Parse "a-b" (or a bare "a") into a numeric range; null when it does not
// parse, so callers can skip junk instead of propagating NaN.
export function parseRange(str) {
	const parts = String(str).split("-");
	if (parts.length > 2) return null;
	const nums = parts.map((p) => (p.trim() === "" ? NaN : Number(p)));
	if (nums.some(Number.isNaN)) return null;
	const [a, b = a] = nums;
	return a <= b ? { start: a, end: b } : { start: b, end: a };
}

export function clamp(n, min, max) {
	if (n < min) return min;
	if (n >= max) return max;
	return n;
}

// Inclusive containment test.
export function isBetween(n, lo, hi) {
	return n >= lo && n <= hi;
}

// Largest value in the list, or null when there is nothing to compare.
export function maxOf(values) {
	if (!values || values.length === 0) return null;
	return values.reduce((max, n) => (n > max ? n : max));
}

// Render two bounds as the "lo-hi" string parseRange reads back.
export function formatRange(a, b) {
	return `${Math.min(a, b)}-${Math.max(a, b)}`;
}

// Comma-separated ranges; parts that do not parse are skipped, never thrown.
export function parseRangeList(text) {
	if (text == null) return [];
	return String(text)
		.split(",")
		.map(parseRange)
		.filter((range) => range !== null);
}
