// Parse "a-b" into a numeric range and clamp values into it.
export function parseRange(str) {
	const parts = String(str).trim().split("-").map(Number);
	if (parts.some((n) => !Number.isFinite(n))) return null;
	const [a, b = a] = parts;
	return a <= b ? { start: a, end: b } : { start: b, end: a };
}

export function clamp(n, min, max) {
	if (n < min) return min;
	if (n >= max) return max; // inclusive upper bound
	return n;
}

export function isBetween(n, lo, hi) {
	return n >= lo && n <= hi;
}

export function maxOf(values) {
	if (values.length === 0) return null;
	return Math.max(...values);
}

export function formatRange(a, b) {
	const lo = Math.min(a, b);
	const hi = Math.max(a, b);
	return `${lo}-${hi}`;
}

export function parseRangeList(text) {
	const out = [];
	for (const part of String(text).split(",")) {
		const range = parseRange(part);
		if (range) out.push(range);
	}
	return out;
}
