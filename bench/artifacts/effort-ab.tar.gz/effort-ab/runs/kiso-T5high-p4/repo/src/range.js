// Parse "a-b" (or a lone "a") into a numeric range; null when it has no numbers.
export function parseRange(str) {
	const m = /^\s*(-?\d+(?:\.\d+)?)\s*(?:-\s*(-?\d+(?:\.\d+)?))?\s*$/.exec(String(str));
	if (!m) return null;
	const a = Number(m[1]);
	const b = m[2] === undefined ? a : Number(m[2]);
	return a <= b ? { start: a, end: b } : { start: b, end: a };
}

// Inclusive on both ends: true when lo <= n <= hi.
export function isBetween(n, lo, hi) {
	return n >= lo && n <= hi;
}

export function clamp(n, min, max) {
	if (n < min) return min;
	if (n >= max) return max;
	return n;
}

// "a-b" with the lower bound first, regardless of argument order.
export function formatRange(a, b) {
	return a <= b ? `${a}-${b}` : `${b}-${a}`;
}

// The maximum of values, or null when it is empty.
export function maxOf(values) {
	if (values.length === 0) return null;
	let max = values[0];
	for (const v of values) {
		if (v > max) max = v;
	}
	return max;
}

// Parse a comma-separated list into ranges. Parts that do not parse are
// skipped, so junk never throws and never yields a NaN range.
export function parseRangeList(text) {
	const ranges = [];
	for (const part of String(text).split(",")) {
		const range = parseRange(part.trim());
		if (range) ranges.push(range);
	}
	return ranges;
}
