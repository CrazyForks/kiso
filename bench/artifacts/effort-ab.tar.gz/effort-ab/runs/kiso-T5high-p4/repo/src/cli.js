import { formatUser } from "./user.js";
import { reportLine, summarize } from "./report.js";

const u = { name: "Ada", email: "ada@example.com" };

const [flag, text] = process.argv.slice(2);

if (flag === "--count") {
	// summarize() parses text with parseRangeList and counts the ranges.
	console.log(summarize(text ?? ""));
} else {
	console.log(formatUser(u));
	console.log(reportLine(u, 3));
}
