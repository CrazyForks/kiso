// Parse "a-b" into a numeric range and clamp values into it.
export function parseRange(str) {
	const parts = String(str).split("-").map(Number);
	if (parts.length === 1) {
		const n = parts[0];
		if (!Number.isFinite(n)) return null;
		return { start: n, end: n };
	}
	if (parts.length !== 2) return null;
	const [a, b] = parts;
	if (!Number.isFinite(a) || !Number.isFinite(b)) return null;
	return a <= b ? { start: a, end: b } : { start: b, end: a };
}

export function clamp(n, min, max) {
	if (n < min) return min;
	if (n > max) return max;
	return n;
}

export function isBetween(n, lo, hi) {
	return lo <= n && n <= hi;
}

export function maxOf(values) {
	if (values.length === 0) return null;
	return Math.max(...values);
}

export function formatRange(a, b) {
	const [start, end] = a <= b ? [a, b] : [b, a];
	return `${start}-${end}`;
}

export function parseRangeList(text) {
	const ranges = [];
	for (const part of String(text).split(",")) {
		try {
			const range = parseRange(part);
			if (range) ranges.push(range);
		} catch {
			// skip parts that do not parse
		}
	}
	return ranges;
}
