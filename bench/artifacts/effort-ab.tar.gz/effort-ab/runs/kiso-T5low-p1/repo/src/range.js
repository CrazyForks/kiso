// Parse "a-b" into a numeric range and clamp values into it.
export function parseRange(str) {
	const parts = str.split("-").map(Number);
	const a = parts[0];
	const b = parts.length > 1 ? parts[1] : a; // a lone number is a degenerate range
	return a <= b ? { start: a, end: b } : { start: b, end: a };
}

export function clamp(n, min, max) {
	if (n < min) return min;
	if (n > max) return max; // inclusive clamp returns max
	return n;
}

export function isBetween(n, lo, hi) {
	return lo <= n && n <= hi;
}

export function maxOf(values) {
	if (values.length === 0) return null;
	return Math.max(...values);
}

export function formatRange(a, b) {
	const [lo, hi] = a <= b ? [a, b] : [b, a];
	return `${lo}-${hi}`;
}

export function parseRangeList(text) {
	const ranges = [];
	for (const part of text.split(",")) {
		const trimmed = part.trim();
		if (trimmed === "") continue;
		const { start, end } = parseRange(trimmed);
		if (Number.isNaN(start) || Number.isNaN(end)) continue; // skip parts that do not parse
		ranges.push({ start, end });
	}
	return ranges;
}
