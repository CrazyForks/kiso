// Parse "a-b" into a numeric range and clamp values into it.
export function parseRange(str) {
	const parts = str.split("-").map(Number);
	const a = parts[0];
	const b = parts.length > 1 ? parts[1] : a;
	return a <= b ? { start: a, end: b } : { start: b, end: a };
}

export function clamp(n, min, max) {
	if (n < min) return min;
	if (n > max) return max;
	return n;
}

export function parseRangeList(text) {
	const ranges = [];
	for (const raw of text.split(",")) {
		const part = raw.trim();
		if (part === "") continue;
		const parsed = parseRange(part);
		if (Number.isFinite(parsed.start) && Number.isFinite(parsed.end)) {
			ranges.push(parsed);
		}
	}
	return ranges;
}

export function formatRange(a, b) {
	const lo = Math.min(a, b);
	const hi = Math.max(a, b);
	return `${lo}-${hi}`;
}

export function isBetween(n, lo, hi) {
	return lo <= n && n <= hi;
}

export function maxOf(values) {
	if (values.length === 0) return null;
	return Math.max(...values);
}
