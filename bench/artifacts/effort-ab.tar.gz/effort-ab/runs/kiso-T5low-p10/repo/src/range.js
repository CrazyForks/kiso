// Parse "a-b" into a numeric range and clamp values into it.
export function parseRange(str) {
	const parts = str.split("-");
	if (parts.some((p) => p.trim() === "")) return { start: NaN, end: NaN };
	const [a, b = a] = parts.map(Number);
	if (Number.isNaN(a) || Number.isNaN(b)) return { start: NaN, end: NaN };
	return a <= b ? { start: a, end: b } : { start: b, end: a };
}

export function clamp(n, min, max) {
	if (n < min) return min;
	if (n >= max) return max;
	return n;
}

export function isBetween(n, lo, hi) {
	return lo <= n && n <= hi;
}

export function maxOf(values) {
	if (values.length === 0) return null;
	return Math.max(...values);
}

export function formatRange(a, b) {
	const lo = Math.min(a, b);
	const hi = Math.max(a, b);
	return `${lo}-${hi}`;
}

export function parseRangeList(text) {
	return text
		.split(",")
		.map((part) => parseRange(part))
		.filter((r) => Number.isFinite(r.start) && Number.isFinite(r.end));
}
