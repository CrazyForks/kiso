// Parse "a-b" (or a single "a", meaning a-a) into a numeric range with
// start <= end. Returns null for text that is not a range, so callers can
// skip bad input without exceptions.
export function parseRange(str) {
	const tokens = str.split("-").map((part) => part.trim());
	const nums = tokens.map((part) => (part === "" ? null : Number(part)));
	if (nums.some((n) => n === null || !Number.isFinite(n))) return null;
	if (nums.length === 1) return { start: nums[0], end: nums[0] };
	if (nums.length !== 2) return null;
	const [a, b] = nums;
	return a <= b ? { start: a, end: b } : { start: b, end: a };
}

export function parseRangeList(text) {
	const ranges = [];
	for (const part of text.split(",")) {
		const range = parseRange(part);
		if (range !== null) ranges.push(range);
	}
	return ranges;
}

export function clamp(n, min, max) {
	if (n < min) return min;
	if (n > max) return max;
	return n;
}

export function isBetween(n, lo, hi) {
	return n >= lo && n <= hi;
}

export function maxOf(values) {
	if (values.length === 0) return null;
	let max = values[0];
	for (let i = 1; i < values.length; i++) {
		if (values[i] > max) max = values[i];
	}
	return max;
}

export function formatRange(a, b) {
	const lo = Math.min(a, b);
	const hi = Math.max(a, b);
	return `${lo}-${hi}`;
}
