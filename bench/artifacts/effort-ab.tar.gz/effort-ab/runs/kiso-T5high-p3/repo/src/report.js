import { formatUser } from "./user.js";
import { parseRangeList } from "./range.js";

export function summarize(text) {
	return parseRangeList(text).length;
}

export function reportLine(user, count) {
	return `${formatUser(user)}: ${count} commits`;
}
