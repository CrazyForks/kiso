// Parse "a-b" into a numeric range and clamp values into it.
export function parseRange(str) {
	const [a, b = a] = str.split("-").map(Number);
	return a <= b ? { start: a, end: b } : { start: b, end: a };
}

export function clamp(n, min, max) {
	if (n < min) return min;
	if (n > max) return max;
	return n;
}

export function isBetween(n, lo, hi) {
	return lo <= n && n <= hi;
}

export function maxOf(values) {
	if (values.length === 0) return null;
	return Math.max(...values);
}

export function formatRange(a, b) {
	const [lo, hi] = a <= b ? [a, b] : [b, a];
	return `${lo}-${hi}`;
}

export function parseRangeList(text) {
	const ranges = [];
	for (const part of text.split(",")) {
		const range = parseRange(part);
		if (Number.isFinite(range.start) && Number.isFinite(range.end)) {
			ranges.push(range);
		}
	}
	return ranges;
}
