// Parse "a-b" (or a lone "a") into a numeric range, or null if it does not parse.
export function parseRange(str) {
	if (str.trim() === "") return null; // Number("") is 0, not a range
	const [a, b] = str.split("-").map(Number);
	if (!Number.isFinite(a)) return null;
	if (b === undefined) return { start: a, end: a };
	if (!Number.isFinite(b)) return null;
	return a <= b ? { start: a, end: b } : { start: b, end: a };
}

// Render a range as "lo-hi", normalising the order so lo <= hi.
export function formatRange(a, b) {
	const lo = Math.min(a, b);
	const hi = Math.max(a, b);
	return `${lo}-${hi}`;
}

// Maximum of the values, or null when there are none.
export function maxOf(values) {
	if (values.length === 0) return null;
	return Math.max(...values);
}

// Inclusive membership test: true when lo <= n <= hi.
export function isBetween(n, lo, hi) {
	return n >= lo && n <= hi;
}

export function clamp(n, min, max) {
	if (n < min) return min;
	if (n > max) return max;
	return n;
}

// Parse a comma-separated list of ranges, skipping parts that do not parse.
export function parseRangeList(text) {
	const ranges = [];
	for (const part of text.split(",")) {
		const range = parseRange(part);
		if (range) ranges.push(range);
	}
	return ranges;
}
