import { formatUser } from "./user.js";
import { parseRangeList } from "./range.js";

export function reportLine(user, count) {
	return `${formatUser(user)}: ${count} commits`;
}

// Number of ranges that parse out of a comma-separated list.
export function summarize(text) {
	return parseRangeList(text).length;
}
