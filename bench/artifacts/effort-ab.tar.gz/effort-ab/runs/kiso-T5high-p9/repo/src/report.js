import { formatUser } from "./user.js";
import { parseRangeList } from "./range.js";

export function reportLine(user, count) {
	return `${formatUser(user)}: ${count} commits`;
}

// How many ranges the text contains; unparseable parts are ignored.
export function summarize(text) {
	return parseRangeList(text).length;
}
