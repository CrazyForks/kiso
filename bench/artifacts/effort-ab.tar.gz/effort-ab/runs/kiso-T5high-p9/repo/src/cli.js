import { formatUser } from "./user.js";
import { reportLine, summarize } from "./report.js";

const [flag, arg] = process.argv.slice(2);

if (flag === "--count") {
	// e.g. `node src/cli.js --count 1-2,3-4` -> 2
	console.log(summarize(arg ?? ""));
} else {
	const u = { name: "Ada", email: "ada@example.com" };
	console.log(formatUser(u));
	console.log(reportLine(u, 3));
}
