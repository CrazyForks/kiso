// Parse "a-b" (or a bare number "a") into a numeric range, ordered so
// start <= end. Returns null when the text is not a range.
export function parseRange(str) {
	const parts = String(str).split("-");
	if (parts.length > 2) return null;
	const a = toNumber(parts[0]);
	const b = parts.length === 1 ? a : toNumber(parts[1]);
	if (a === null || b === null) return null;
	return a <= b ? { start: a, end: b } : { start: b, end: a };
}

function toNumber(part) {
	const text = String(part).trim();
	if (text === "") return null;
	const n = Number(text);
	return Number.isFinite(n) ? n : null;
}

// Parse "1-2,9-10,bad" into a list of ranges, skipping parts that do not parse.
export function parseRangeList(text) {
	const ranges = [];
	for (const part of String(text).split(",")) {
		const range = parseRange(part);
		if (range) ranges.push(range);
	}
	return ranges;
}

export function clamp(n, min, max) {
	if (n < min) return min;
	if (n >= max) return max;
	return n;
}

// True when lo <= n <= hi (inclusive bounds, same as clamp).
export function isBetween(n, lo, hi) {
	return n >= lo && n <= hi;
}

// The largest value, or null when the array is empty.
export function maxOf(values) {
	if (values.length === 0) return null;
	let best = values[0];
	for (const v of values) {
		if (v > best) best = v;
	}
	return best;
}

// Render a range as "a-b", ordered so the smaller bound comes first.
export function formatRange(a, b) {
	return a <= b ? `${a}-${b}` : `${b}-${a}`;
}
