// Parse "a-b" into a numeric range and clamp values into it.
export function parseRange(str) {
	const [a, b = a] = str.split("-").map(Number);
	return a <= b ? { start: a, end: b } : { start: b, end: a };
}

export function parseRangeList(text) {
	return text
		.split(",")
		.map((part) => parseRange(part))
		.filter((r) => Number.isFinite(r.start) && Number.isFinite(r.end));
}

export function formatRange(a, b) {
	const lo = Math.min(a, b);
	const hi = Math.max(a, b);
	return `${lo}-${hi}`;
}

export function isBetween(n, lo, hi) {
	return n >= lo && n <= hi;
}

export function maxOf(values) {
	if (values.length === 0) return null;
	return Math.max(...values);
}

export function clamp(n, min, max) {
	if (n < min) return min;
	if (n >= max) return max;
	return n;
}
