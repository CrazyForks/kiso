// Parse "a-b" (or a lone "a") into a numeric range.
// Returns null when the text is not a valid range.
export function parseRange(str) {
	const text = String(str).trim();
	if (text === "") return null;
	const parts = text.split("-").map(Number);
	if (parts.length === 1) {
		const [n] = parts;
		return Number.isFinite(n) ? { start: n, end: n } : null;
	}
	if (parts.length === 2) {
		const [a, b] = parts;
		if (!Number.isFinite(a) || !Number.isFinite(b)) return null;
		return a <= b ? { start: a, end: b } : { start: b, end: a };
	}
	return null;
}

export function clamp(n, min, max) {
	if (n < min) return min;
	if (n >= max) return max;
	return n;
}

export function isBetween(n, lo, hi) {
	return n >= lo && n <= hi;
}

export function maxOf(values) {
	if (values.length === 0) return null;
	return Math.max(...values);
}

export function formatRange(a, b) {
	const lo = Math.min(a, b);
	const hi = Math.max(a, b);
	return `${lo}-${hi}`;
}

// Split on commas, parse each part, and drop parts with no valid range.
export function parseRangeList(text) {
	return String(text)
		.split(",")
		.map((part) => parseRange(part))
		.filter((range) => range !== null);
}
