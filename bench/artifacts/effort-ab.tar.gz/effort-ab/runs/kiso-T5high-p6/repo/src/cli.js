import { formatUser } from "./user.js";
import { reportLine, summarize } from "./report.js";

const args = process.argv.slice(2);

if (args[0] === "--count") {
	console.log(summarize(args[1] ?? ""));
} else {
	const u = { name: "Ada", email: "ada@example.com" };
	console.log(formatUser(u));
	console.log(reportLine(u, 3));
}
