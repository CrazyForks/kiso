// Parse "a-b" (or a lone "a" as the degenerate range a-a) into a range.
// A part that does not parse yields NaN bounds.
export function parseRange(str) {
	const parts = String(str).split("-").map((s) => s.trim());
	if (parts.some((s) => s === "" || Number.isNaN(Number(s)))) {
		return { start: NaN, end: NaN };
	}
	const [a, b = a] = parts.map(Number);
	return a <= b ? { start: a, end: b } : { start: b, end: a };
}

// Split on commas and parse each part, skipping any part that does not parse.
export function parseRangeList(text) {
	return String(text)
		.split(",")
		.map((part) => parseRange(part))
		.filter((r) => !Number.isNaN(r.start) && !Number.isNaN(r.end));
}

export function clamp(n, min, max) {
	if (n < min) return min;
	if (n >= max) return max;
	return n;
}

export function isBetween(n, lo, hi) {
	return lo <= n && n <= hi;
}

export function maxOf(values) {
	if (values.length === 0) return null;
	return Math.max(...values);
}

export function formatRange(a, b) {
	return a <= b ? `${a}-${b}` : `${b}-${a}`;
}
