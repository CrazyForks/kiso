// Parse "a-b" into a numeric range and clamp values into it.
// A bare number "a" is a single-point range; junk yields NaN bounds.
export function parseRange(str) {
	const text = String(str).trim();
	if (text === "") return { start: NaN, end: NaN };
	const parts = text.split("-").map(Number);
	if (parts.length === 1) {
		const n = parts[0];
		return Number.isFinite(n) ? { start: n, end: n } : { start: NaN, end: NaN };
	}
	const [a, b] = parts;
	return a <= b ? { start: a, end: b } : { start: b, end: a };
}

export function clamp(n, min, max) {
	if (n < min) return min;
	if (n > max) return max;
	return n;
}

export function isBetween(n, lo, hi) {
	return n >= lo && n <= hi;
}

export function maxOf(values) {
	if (values.length === 0) return null;
	let max = values[0];
	for (const v of values) {
		if (v > max) max = v;
	}
	return max;
}

export function formatRange(a, b) {
	return a <= b ? `${a}-${b}` : `${b}-${a}`;
}

export function parseRangeList(text) {
	const ranges = [];
	for (const part of String(text).split(",")) {
		let range;
		try {
			range = parseRange(part);
		} catch {
			continue; // unparseable part: skip it
		}
		if (Number.isFinite(range.start) && Number.isFinite(range.end)) {
			ranges.push(range);
		}
	}
	return ranges;
}
