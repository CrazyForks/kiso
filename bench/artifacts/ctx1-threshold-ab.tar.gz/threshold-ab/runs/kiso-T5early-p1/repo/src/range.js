// Parse "a-b" into a numeric range and clamp values into it.
export function parseRange(str) {
	const [a, b] = str.split("-").map(Number);
	return a <= b ? { start: a, end: b } : { start: b, end: a };
}

export function parseRangeList(text) {
	const ranges = [];
	for (const part of String(text).split(",")) {
		const tokens = part.split("-").map((t) => t.trim());
		if (tokens.length === 1) {
			const n = Number(tokens[0]);
			if (tokens[0] !== "" && Number.isFinite(n)) ranges.push({ start: n, end: n });
			continue;
		}
		const ok = tokens.length === 2 && tokens.every((t) => t !== "" && Number.isFinite(Number(t)));
		if (ok) ranges.push(parseRange(part));
	}
	return ranges;
}

export function formatRange(a, b) {
	return a <= b ? `${a}-${b}` : `${b}-${a}`;
}

export function isBetween(n, lo, hi) {
	return lo <= n && n <= hi;
}

export function maxOf(values) {
	if (values.length === 0) return null;
	let max = values[0];
	for (let i = 1; i < values.length; i++) {
		if (values[i] > max) max = values[i];
	}
	return max;
}

export function clamp(n, min, max) {
	if (n < min) return min;
	if (n >= max) return max;
	return n;
}
