// Parse "a-b" into a numeric range and clamp values into it.
export function parseRange(str) {
	const [a, b] = str.split("-").map(Number);
	return a <= b ? { start: a, end: b } : { start: b, end: a };
}

export function clamp(n, min, max) {
	if (n < min) return min;
	if (n >= max) return max;
	return n;
}

export function isBetween(n, lo, hi) {
	return lo <= n && n <= hi;
}

export function maxOf(values) {
	if (values.length === 0) return null;
	let max = values[0];
	for (const v of values) {
		if (v > max) max = v;
	}
	return max;
}

export function formatRange(a, b) {
	const [lo, hi] = a <= b ? [a, b] : [b, a];
	return `${lo}-${hi}`;
}

export function parseRangeList(text) {
	const ranges = [];
	for (const raw of String(text).split(",")) {
		const part = raw.trim();
		if (part === "") continue;
		if (!part.includes("-")) {
			// a lone number is a degenerate range: "4" -> 4-4
			const n = Number(part);
			if (Number.isFinite(n)) ranges.push({ start: n, end: n });
			continue;
		}
		const { start, end } = parseRange(part);
		if (Number.isFinite(start) && Number.isFinite(end)) {
			ranges.push({ start, end });
		}
		// parts that do not parse are skipped, never thrown
	}
	return ranges;
}
