const NUM = String.raw`(-?\d+(?:\.\d+)?)`;
const PAIR = new RegExp(String.raw`^\s*${NUM}\s*-\s*${NUM}\s*$`);
const SINGLE = new RegExp(String.raw`^\s*${NUM}\s*$`);

// Parse "a-b" (or a single number "a") into an ordered numeric range,
// i.e. { start, end } with start <= end. Returns null when the text is
// not a number or a "-"-separated pair of numbers.
export function parseRange(str) {
	const pair = PAIR.exec(str);
	if (pair) {
		const a = Number(pair[1]);
		const b = Number(pair[2]);
		return a <= b ? { start: a, end: b } : { start: b, end: a };
	}
	const single = SINGLE.exec(str);
	if (single) {
		const n = Number(single[1]);
		return { start: n, end: n };
	}
	return null;
}

export function clamp(n, min, max) {
	if (n < min) return min;
	if (n > max) return max;
	return n;
}

export function isBetween(n, lo, hi) {
	return n >= lo && n <= hi;
}

export function maxOf(values) {
	if (values.length === 0) return null;
	let max = values[0];
	for (const v of values) {
		if (v > max) max = v;
	}
	return max;
}

export function formatRange(a, b) {
	const [lo, hi] = a <= b ? [a, b] : [b, a];
	return `${lo}-${hi}`;
}

// Split comma-separated ranges and parse each one; parts that do not
// parse are skipped rather than raising.
export function parseRangeList(text) {
	return String(text)
		.split(",")
		.map((part) => parseRange(part))
		.filter((range) => range !== null);
}
