import { formatUser } from "./user.js";
import { parseRangeList } from "./range.js";

export function reportLine(user, count) {
	return `${formatUser(user)}: ${count} commits`;
}

// Count how many ranges the text parses into.
export function summarize(text) {
	return parseRangeList(text).length;
}
