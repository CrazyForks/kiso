import { formatUser } from "./user.js";
import { parseRangeList } from "./range.js";

export function reportLine(user, count) {
	return `${formatUser(user)}: ${count} commits`;
}

// How many valid ranges the text describes.
export function summarize(text) {
	return parseRangeList(text).length;
}
