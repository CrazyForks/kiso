// Parse "a-b" into a numeric range and clamp values into it.
export function parseRange(str) {
	const [a, b] = str.split("-").map(Number);
	return a <= b ? { start: a, end: b } : { start: b, end: a };
}

export function clamp(n, min, max) {
	if (n < min) return min;
	if (n > max) return max;
	return n;
}

// Inclusive bounds check: lo <= n <= hi.
export function isBetween(n, lo, hi) {
	return lo <= n && n <= hi;
}

// Largest number in values, or null when values is empty.
export function maxOf(values) {
	if (values.length === 0) return null;
	let max = values[0];
	for (const n of values) {
		if (n > max) max = n;
	}
	return max;
}

// Inverse of parseRange: "lo-hi" with the smaller bound first.
export function formatRange(a, b) {
	const lo = a <= b ? a : b;
	const hi = a <= b ? b : a;
	return `${lo}-${hi}`;
}

// Parse comma-separated ranges, dropping parts that do not parse.
// A bare number ("4") is shorthand for the degenerate range 4-4.
export function parseRangeList(text) {
	const ranges = [];
	for (const part of text.split(",")) {
		const trimmed = part.trim();
		const bare = Number(trimmed);
		if (trimmed !== "" && Number.isFinite(bare)) {
			ranges.push({ start: bare, end: bare });
			continue;
		}
		const range = parseRange(part);
		if (Number.isFinite(range.start) && Number.isFinite(range.end)) {
			ranges.push(range);
		}
	}
	return ranges;
}
