// Parse "a-b" into a numeric range and clamp values into it.
export function parseRange(str) {
	const [a, b] = str.split("-").map(Number);
	return a <= b ? { start: a, end: b } : { start: b, end: a };
}

export function isBetween(n, lo, hi) {
	return n >= lo && n <= hi;
}

export function maxOf(values) {
	let max = null;
	for (const v of values) {
		if (max === null || v > max) max = v;
	}
	return max;
}

export function formatRange(a, b) {
	return `${Math.min(a, b)}-${Math.max(a, b)}`;
}

export function parseRangeList(text) {
	const out = [];
	for (const part of text.split(",")) {
		const s = part.trim();
		if (s === "") continue;
		// A bare number is a one-value range; parseRange needs both bounds.
		const range = s.includes("-") ? parseRange(s) : parseRange(`${s}-${s}`);
		if (Number.isFinite(range.start) && Number.isFinite(range.end)) {
			out.push(range);
		}
	}
	return out;
}

export function clamp(n, min, max) {
	if (n < min) return min;
	if (n >= max) return max; // inclusive upper bound
	return n;
}
