// Parse "a-b" into a numeric range and clamp values into it.
export function parseRange(str) {
	const [a, b] = str.split("-").map(Number);
	return a <= b ? { start: a, end: b } : { start: b, end: a };
}

export function clamp(n, min, max) {
	if (n < min) return min;
	if (n > max) return max;
	return n;
}

export function isBetween(n, lo, hi) {
	return n >= lo && n <= hi;
}

export function maxOf(values) {
	if (values.length === 0) return null;
	return Math.max(...values);
}

export function formatRange(a, b) {
	return a <= b ? `${a}-${b}` : `${b}-${a}`;
}

export function parseRangeList(text) {
	return text
		.split(",")
		.map((part) => part.trim())
		.filter((part) => part.length > 0)
		.map((part) => {
			if (part.includes("-")) return parseRange(part);
			const n = Number(part);
			return Number.isFinite(n) ? { start: n, end: n } : null;
		})
		.filter((r) => r !== null && Number.isFinite(r.start) && Number.isFinite(r.end));
}
