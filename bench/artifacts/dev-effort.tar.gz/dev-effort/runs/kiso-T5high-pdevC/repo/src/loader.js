import { readFileSync } from "node:fs";
import { validateRecords } from "./validate.js";

export function loaderRead(path) {
	return validateRecords(JSON.parse(readFileSync(path, "utf8")));
}

export function loaderCount(path) {
	return loaderRead(path).length;
}
