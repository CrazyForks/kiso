import { readFileSync } from "node:fs";
import { validateRecords } from "./validate.js";

export function importerRead(path) {
	return validateRecords(JSON.parse(readFileSync(path, "utf8")));
}

export function importerCount(path) {
	return importerRead(path).length;
}
