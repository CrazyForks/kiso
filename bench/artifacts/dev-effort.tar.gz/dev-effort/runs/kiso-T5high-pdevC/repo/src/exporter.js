import { readFileSync } from "node:fs";
import { validateRecords } from "./validate.js";

export function exporterRead(path) {
	return validateRecords(JSON.parse(readFileSync(path, "utf8")));
}

export function exporterCount(path) {
	return exporterRead(path).length;
}
