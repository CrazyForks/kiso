import { parseArgs } from "./parse.js";
import { aggregate, sortEntries, topN } from "./compute.js";
import { formatTable, formatJson } from "./format.js";
import { readFileSync } from "node:fs";

export function run(argv) {
	const opts = parseArgs(argv);
	const rows = JSON.parse(readFileSync(opts.file, "utf8"));
	const sorted = sortEntries(aggregate(rows), opts.sort);
	const entries = topN(sorted, opts.top);
	return opts.json ? formatJson(entries) : formatTable(entries);
}
