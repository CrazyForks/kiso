import { readRecords } from "./validate.js";

export function importerRead(path) {
	return readRecords(path);
}

export function importerCount(path) {
	return importerRead(path).length;
}
