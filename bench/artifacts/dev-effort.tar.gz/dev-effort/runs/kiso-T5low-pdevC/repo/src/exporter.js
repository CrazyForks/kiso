import { readRecords } from "./validate.js";

export function exporterRead(path) {
	return readRecords(path);
}

export function exporterCount(path) {
	return exporterRead(path).length;
}
