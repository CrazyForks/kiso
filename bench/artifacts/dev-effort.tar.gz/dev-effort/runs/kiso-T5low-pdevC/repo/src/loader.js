import { readRecords } from "./validate.js";

export function loaderRead(path) {
	return readRecords(path);
}

export function loaderCount(path) {
	return loaderRead(path).length;
}
