import { formatUser } from "./user.js";
import { reportLine, summarize } from "./report.js";

const [, , first, second] = process.argv;

if (first === "--count") {
	console.log(summarize(second ?? ""));
} else {
	const u = { name: "Ada", email: "ada@example.com" };
	console.log(formatUser(u));
	console.log(reportLine(u, 3));
}
