// Parse "a-b" — or a lone "a" — into a numeric range; null when it is neither.
export function parseRange(str) {
	const parts = String(str).trim().split("-");
	if (parts.some((part) => part.trim() === "")) return null;
	const nums = parts.map(Number);
	if (nums.some((n) => !Number.isFinite(n))) return null;
	if (nums.length === 1) return { start: nums[0], end: nums[0] };
	if (nums.length !== 2) return null;
	const [a, b] = nums;
	return a <= b ? { start: a, end: b } : { start: b, end: a };
}

export function parseRangeList(text) {
	return String(text)
		.split(",")
		.map((part) => parseRange(part))
		.filter((range) => range !== null);
}

export function formatRange(a, b) {
	const [lo, hi] = a <= b ? [a, b] : [b, a];
	return `${lo}-${hi}`;
}

export function maxOf(values) {
	if (values.length === 0) return null;
	return Math.max(...values);
}

export function isBetween(n, lo, hi) {
	return n >= lo && n <= hi;
}

export function clamp(n, min, max) {
	if (n < min) return min;
	if (n > max) return max;
	return n;
}
