const toNum = (s) => {
	const t = String(s).trim();
	return t === "" ? NaN : Number(t);
};

// Parse "a-b" (or a bare number "a") into { start, end } with start <= end.
// Returns null when the text does not parse.
export function parseRange(str) {
	const parts = String(str).split("-");
	if (parts.length === 1) {
		const n = toNum(parts[0]);
		return Number.isFinite(n) ? { start: n, end: n } : null;
	}
	if (parts.length !== 2) return null;
	const [a, b] = parts.map(toNum);
	if (!Number.isFinite(a) || !Number.isFinite(b)) return null;
	return a <= b ? { start: a, end: b } : { start: b, end: a };
}

export function clamp(n, min, max) {
	if (n < min) return min;
	if (n >= max) return max;
	return n;
}

// Inclusive membership test: lo <= n <= hi.
export function isBetween(n, lo, hi) {
	return n >= lo && n <= hi;
}

// Largest value in the array, or null when it is empty.
export function maxOf(values) {
	if (values.length === 0) return null;
	return Math.max(...values);
}

// Canonical "lo-hi" string; the bounds are ordered so that lo <= hi.
export function formatRange(a, b) {
	const lo = Math.min(a, b);
	const hi = Math.max(a, b);
	return `${lo}-${hi}`;
}

// Parse a comma-separated list of ranges, skipping parts that do not parse.
export function parseRangeList(text) {
	const ranges = [];
	for (const part of String(text).split(",")) {
		const range = parseRange(part);
		if (range !== null) ranges.push(range);
	}
	return ranges;
}
