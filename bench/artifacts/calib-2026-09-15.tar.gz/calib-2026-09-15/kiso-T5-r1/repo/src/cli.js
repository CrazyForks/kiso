import { formatUser } from "./user.js";
import { reportLine, summarize } from "./report.js";

const [flag, text] = process.argv.slice(2);

if (flag === "--count") {
	// summarize(text) === parseRangeList(text).length
	console.log(summarize(text));
} else {
	const u = { name: "Ada", email: "ada@example.com" };
	console.log(formatUser(u));
	console.log(reportLine(u, 3));
}
